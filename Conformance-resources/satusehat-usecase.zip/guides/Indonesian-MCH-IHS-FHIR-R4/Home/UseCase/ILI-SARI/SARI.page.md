## <b>SARI (Severe Acute Respiratory Infections)</b>
*Last Updated: 2023/12/20*

## A. Pendahuluan
Tahapan alur integrasi dan resource yang digunakan untuk integrasi pelaporan kasus SARI dapat dilihat pada gambar dibawah ini.
<center>
<img src="https://victoriatjia.github.io/Guideline/SatuSehat/Specs%20Format%20FHIR/covid_pelaporan_sari_v2.0.png" alt="covid-skema-pelaporan-sari" title="Pelaporan Kasus SARI Workflow" width="100%" style="max-width: 850px;">

*Gambar 2. Alur Integrasi Pelaporan SARI*
</center>

## B. Strategi Pengiriman Data ke SATUSEHAT
SATUSEHAT menyediakan dua pilihan cara mengirimkan data use case ILI:

### 1. Berbasis Resource
Data dapat dikirimkan secara berurutan sesuai resource yang terlibat pada alur pelayanan terkait. Sebagai contoh: ketika mengirimkan data registrasi kasus saja yang berisikan resource Encounter dan Condition, maka implementor mengirimkan resource-resource tersebut ke SATUSEHAT secara berurutan sesuai dependensinya.

### 2. Berbasis Bundle
Data dapat dikirimkan seluruh resource yang terlibat pada alur pelayanan terkait dengan menggunakan satu langkah pengiriman data ke SATUSEHAT menggunakan profil FHIR bernama Bundle.

Resource-resource yang terlibat di setiap tahapan alur pelayanan untuk use case ILI adalah sebagai berikut:

<style>
.table-fhir-resources {
    border-collapse: collapse;
}
.table-fhir-resources, .table-fhir-resources th, .table-fhir-resources td {
   border: 1px solid black;
}

.table-fhir-resources th, .table-fhir-resources td {
   padding: 5px;
}
</style>

<table class="table-fhir-resources">
<tr>
	<th>Category</th>
	<th>No</th>
	<th>Resource</th>
	<th>Entry Mandatory</th>
</tr>
<tr>
	<td rowspan="5">Base</td>
	<td>1</td>
	<td>Patient</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>2</td>
	<td>Practitioner</td>
	<td><b>Required</b></td>
</tr>

<tr>
	<td>3</td>
	<td>Organization</td>
	<td><b>Required</b></td>
</tr>

<tr>
	<td>4</td>
	<td>Location</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>5</td>
	<td>Encounter *</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td rowspan="8">Clinical</td>
	<td>6</td>
	<td>Condition</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>7</td>
	<td>Observation</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>8</td>
	<td>ServiceRequest</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>9</td>
	<td>Specimen</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>10</td>
	<td>QuestionnaireResponse</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>11</td>
	<td>DiagnosticReport</td>
	<td><b>Required</b></td>
</tr>
<tr>
	<td>12</td>
	<td>Composition</td>
	<td><b>Required</b></td>
</tr>
</table>

<br>_Notes:_<br>
1. *) Profile Resource yang direkomendasikan tersedia pada proses pencatatan
2. __Required__: Entry resource harus dilibatkan setiap kali mengirimkan bundle
3. _Optional_: Entry resource dapat tidak dilibatkan setiap kali mengirimkan bundle

## C. Langkah-Langkah Pengiriman Data ke SATUSEHAT
### <div id="SearchPatientPractitionerOrganization"> [Pre-Use Case Requirement] Pencarian Data Pasien</div>

<div style="margin-left: 30px;">
<p>Apabila melakukan pengiriman data kesehatan melalui SATUSEHAT yang memiliki elemen data terkait pasien, maka diperlukan informasi {patient-ihs-number} dari pasien yang bersangkutan. {patient-ihs-number} seorang pasien didapatkan dari Master Patient Index (MPI) Kementerian Kesehatan. MPI menyimpan data-data demografi pasien berskala nasional, mulai dari nama, tanggal lahir, alamat, IDentitas resmi yang diterbitkan pemerintah, dan lain lain. Setelah mendapatkan {patient-ihs-number}, ID dapat disimpan secara di masing-masing sistem internal fasyankes maupun partner non-fasyankes. {patient-ihs-number} akan mempermudah pelaporan pelayanan kesehatan yang berhubungan dengan pasien, karena partner tidak diwajibkan menyertakan data diri setiap ada pengiriman data {patient-ihs-number} juga dapat digunakan untuk melihat data diri pasien secara menyeluruh.</p>

> `CATATAN:`
>  Proses pencarian `{patient-ihs-number}` dari pasien dapat dilakukan melalui FHIR API dengan metode GET. Untuk metode pencarian data pasien di SATUSEHAT secara detail dapat dilihat dalam _resource_ [`Patient`](https://satusehat.kemkes.go.id/platform/docs/id/fhir/resources/patient/#patient) dan terkait panduan/playbook MPI dapat dilihat dalam dokumen  <a href="https://satusehat.kemkes.go.id/platform/docs/id/master-data/master-patient-index/preliminary/#prem-mpi" target="_blank">Master Patient Index</a>.

### <div id="">Step 1. Pendataan Kunjungan Rawat Inap (Awal Masuk)</div>

<div style="margin-left: 30px;">
Kunjungan pasien dapat didefinisikan sebagai interaksi pasien terhadap suatu layanan fasyankes. Sebagai contoh, dalam satu rangkaian rawat jalan, seluruh rangkaian dapat didefinisikan sebagai satu “Encounter”. Data-data kunjungan pasien yang direkam meliputi kapan pertemuan tersebut mulai dan selesai, siapa tenaga kesehatan yang melayani, siapa subjek dari pelayanannya, dan informasi pendukung lainnya.


<!--Part 1-1 Variable Pendataan Kunjungan Rawat Jalan-->
<h4 style="font-weight: bold;">Pendataan Kunjungan Rawat Inap</h4>

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-1-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-1-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-1-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-1-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-1-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-Encounter-Arrived--Create-PendataanKunjunganRawatInap}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

<pre style="background: #F6F8F8;border: 1px solid #e8edee; color: maroon;">
{
    "resourceType": "Encounter",
    "identifier": [
        {
            "system": "http://sys-ids.kemkes.go.id/encounter/<strong style="color:#00a7ff">&lcub;&lcub;FACILITY_IHS_NUMBER&rcub;&rcub;</strong>",
            "value": "<strong style="color:#00a7ff">&lcub;&lcub;ENCOUNTER_LOCAL_CODE&rcub;&rcub;</strong>"
        }
    ],
    "status": "arrived",
    "class": {
        "system": "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code": "AMB",
        "display": "ambulatory"
    },
    "subject": {
        "reference": "Patient/<strong style="color:#00a7ff">&lcub;&lcub;PATIENT_IHS_NUMBER&rcub;&rcub;</strong>",
        "display": "<strong style="color:#00a7ff">&lcub;&lcub;PATIENT_NAME&rcub;&rcub;</strong>"
    },
    "participant": [
        {
            "type": [
                {
                    "coding": [
                        {
                            "system": "http://terminology.hl7.org/CodeSystem/v3-ParticipationType",
                            "code": "ATND",
                            "display": "attender"
                        }
                    ]
                }
            ],
            "individual": {
                "reference": "Practitioner/<strong style="color:#00a7ff">&lcub;&lcub;DOCTOR_IHS_NUMBER&rcub;&rcub;</strong>",
                "display": "<strong style="color:#00a7ff">&lcub;&lcub;DOCTOR_NAME&rcub;&rcub;</strong>"
            }
        }
    ],
    "period": {
        "start": "<strong style="color:#00a7ff">&lcub;&lcub;ENCOUNTER_PERIOD1_START&rcub;&rcub;</strong>"
    },
    "location": [
        {
            "location": {
                "reference": "Location/<strong style="color:#00a7ff">&lcub;&lcub;ENCOUNTER_LOCATION_ID&rcub;&rcub;</strong>",
                "display": "<strong style="color:#00a7ff">&lcub;&lcub;ENCOUNTER_LOCATION_NAME&rcub;&rcub;</strong>"
            }
        }
    ],
    "statusHistory": [
        {
            "status": "arrived",
            "period": {
                "start": "<strong style="color:#00a7ff">&lcub;&lcub;ENCOUNTER_PERIOD1_START&rcub;&rcub;</strong>",
                "end": "<strong style="color:#00a7ff">&lcub;&lcub;ENCOUNTER_PERIOD1_END&rcub;&rcub;</strong>"
            }
        }
    ],
    "serviceProvider": {
        "reference": "Organization/<strong style="color:#00a7ff">&lcub;&lcub;FACILITY_IHS_NUMBER&rcub;&rcub;</strong>"
    }
}


</pre>

</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

| Variabel                       | Deskripsi |
| ------------------------------ | --------- |
| __ENCOUNTER_LOCAL_CODE__   | ID Lokal untuk Kunjungan/Encounter |
| __PATIENT_IHS_NUMBER__     | SATUSEHAT ID Number untuk Pasien |
| __PATIENT_NAME__           | Nama Pasien |
| __DOCTOR_IHS_NUMBER__      | SATUSEHAT ID untuk Dokter/Nakes |
| __DOCTOR_NAME__            | Nama Dokter/Nakes |
| __FACILITY_IHS_NUMBER__    | SATUSEHAT ID untuk FASYANKES |
| __ENCOUNTER_PERIOD1_START__| Waktu mulai/check-in kunjungan |
| __ENCOUNTER_PERIOD1_END__  | Waktu mulai/check-out kunjungan |
| __ENCOUNTER_LOCATION_ID__  | ID Location tempat kunjungan dilakukan |
| __ENCOUNTER_LOCATION_NAME__| Nama Location tempat kunjungan dilakukan |

</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 1-1-->


<!--Part 1-2-->
<h4 style="font-weight: bold;">Diagnosa Awal Saat Masuk</h4>

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-1-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-1-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-1-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-1-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-1-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-Condition-Create-DiagnosaAwalSaatMasuk}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 1-2-->

</div>

### <div id="">Step 2. Kondisi Pasien</div>

<div style="margin-left: 30px;">
Data terkait kondisi pasien pada modul ILI mencakup informasi sebagai berikut:<br>
1. Suhu (resource Observation)<br>
2. Riwayat Demam (resource Condition)<br>
3. Gejala & Tanggal Mulai Gejala SARI (resource Condition)<br>
4. Frekuensi napas (resource Observation)<br>
5. Kondisi medis (resource Observation)<br>
6. Faktor Penularan(resource QuestionnaireResponse)<br>
7. Tanggal Wawancara (resource Observation)<br>

<!--Part 2-1-->
<h4 style="font-weight: bold;">Suhu</h4>

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-2-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-2-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-2-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-2-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-2-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-Observation-Create-BodyTemperature}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

| Variabel                       | Deskripsi |
| ------------------------------ | --------- |
| __PATIENT_IHS_NUMBER__             | SATUSEHAT ID Number untuk Pasien |
| __DOCTOR_IHS_NUMBER__              | SATUSEHAT ID untuk Dokter/Nakes |
| __ENCOUNTER_REFERENCE_ID__         | SATUSEHAT ID untuk Encounter |
| __ENCOUNTER_DISPLAY_TEXT__         | Teks Keterangan untuk Encounter |
| __OBSERVATION_EFFECTIVE_DATETIME__ | Waktu Observation dilakukan |
| __OBSERVATION_BODY_TEMPERATURE__   | Hasil Observation suhu badan |

</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 2-1-->

<!--Part 2-6-->
<h4 style="font-weight: bold;">Riwayat Demam</h4>
<h5>Riwayat Demam - Ya</h5>

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-2-6" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-2-6" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-2-6" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-2-6" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-2-6">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-Condition-Create-Riwayatdemamdalam10hariterakhir}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-2-6" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-6" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

| Variabel                       | Deskripsi |
| ------------------------------ | --------- |
| __PATIENT_IHS_NUMBER__             | SATUSEHAT ID Number untuk Pasien |
| __DOCTOR_IHS_NUMBER__              | SATUSEHAT ID untuk Dokter/Nakes |
| __ENCOUNTER_REFERENCE_ID__         | SATUSEHAT ID untuk Encounter |
| __ENCOUNTER_DISPLAY_TEXT__         | Teks Keterangan untuk Encounter |
| __OBSERVATION_EFFECTIVE_DATETIME__ | Waktu Observation dilakukan |
| __OBSERVATION_VALUE__   | Hasil Observation  |

</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-2-6" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 2-6-->


<!--Part 2-3-->
<h4 style="font-weight: bold;">Gejala & Tanggal Mulai Gejala SARI</h4>
<h5>Gejala batuk</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-2-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-2-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-2-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-2-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-2-3">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-Condition-Create-Riwayatdemamdalam10hariterakhir}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 2-3-->

<!--Part 2-2-->
<h4 style="font-weight: bold;">Frekuensi Napas</h4>

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-2-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-2-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-2-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-2-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-2-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-Observation-Create-Pemeriksaanfrekuensipernapasan}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 2-2-->

<!--Part 2-4-->
<h4 style="font-weight: bold;">Kondisi Medis</h4>
<h5>Merokok</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-2-4" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-2-4" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-2-4" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-2-4" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-2-4">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-Observation-Create-RiskFactor-Smoke}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-2-4" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-4" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-2-4" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 2-4-->

<!--Part 2-5 Variable Wawancara Faktor Penularan-->
<h4 style="font-weight: bold;">Faktor Penularan</h4>
Selain melakukan anamnesis dan pemeriksaan fisik, wawancara faktor penularan adalah kegiatan yang penting dilakukan untuk memberikan informasi epidemiologis. Data dari proses pemeriksaan dapat dikirimkan resource QuestionnaireResponse

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-2-5" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-2-5" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-2-5" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-2-5" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-2-5">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-QuestionnaireResponse-Create-WawancaraFaktorPenularan}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-2-5" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-5" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-2-5" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 2-5-->

<!--Part 2-7-->
<h4 style="font-weight: bold;">Tanggal Wawancara</h4>

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-2-7" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-2-7" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-2-7" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-2-7" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-2-7">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-Observation-Create-TanggalWawancara}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-2-7" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-7" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

| Variabel                       | Deskripsi |
| ------------------------------ | --------- |
| __PATIENT_IHS_NUMBER__             | SATUSEHAT ID Number untuk Pasien |
| __DOCTOR_IHS_NUMBER__              | SATUSEHAT ID untuk Dokter/Nakes |
| __ENCOUNTER_REFERENCE_ID__         | SATUSEHAT ID untuk Encounter |
| __ENCOUNTER_DISPLAY_TEXT__         | Teks Keterangan untuk Encounter |
| __OBSERVATION_EFFECTIVE_DATETIME__ | Waktu Observation dilakukan |
| __OBSERVATION_VALUE__   | Hasil Observation  |

</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-2-7" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 2-7-->

</div>
<!--END Part 2-->

<!--Part 3-->
### <div id="labRequest">Step 3. Permintaan Pemeriksaan (Laboratorium Pemeriksa/Dituju)</div>

<div style="margin-left: 30px;">
Data mengenai permintaan pemeriksaan swab nasal ataupun tenggorokan dapat dikirimkan dengan resource ServiceRequest.

<!--Part 3-1-->
<h4 style="font-weight: bold;">A. Rujukan dari Faskes Sentinel ke Lab Terpilih</h4>
<h5>Permintaan Pemeriksaan COVID-19 PCR</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-3-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-3-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-3-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-3-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-3-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-ServiceRequest-Create-PermintaanPemeriksaanCOVID-19PCR}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-3-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-3-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-3-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 3-1-->


<!--Part 3-2-2-->
<h5>Permintaan Pemeriksaan Influenza A</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-3-2-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-3-2-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-3-2-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-3-2-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-3-2-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid/ili/ServiceRequest-Create-PermintaanPemeriksaanInfluenzaA-2.json}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-3-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-3-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-3-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 3-2-2-->


<!--Part 3-2-3-->
<h5>Permintaan Pemeriksaan Influenza B</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-3-2-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-3-2-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-3-2-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-3-2-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-3-2-3">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid/ili/ServiceRequest-Create-PermintaanPemeriksaanInfluenzaB-2.json}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-3-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-3-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-3-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 3-2-3-->

<!--Part 3-2-->
<h4 style="font-weight: bold;">B. Permintaan Pemeriksaan Laboratorium Dalam Faskes</h4>
<h5>Permintaan Pemeriksaan COVID-19 PCR</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-3-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-3-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-3-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-3-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-3-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-ServiceRequest-Create-PermintaanPemeriksaanCOVID-19PCR-2}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-3-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-3-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-3-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 3-2-->


<!--Part 3-2-2-->
<h5>Permintaan Pemeriksaan Influenza A</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-3-2-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-3-2-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-3-2-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-3-2-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-3-2-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid/ili/ServiceRequest-Create-PermintaanPemeriksaanInfluenzaA-2.json}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-3-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-3-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-3-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 3-2-2-->


<!--Part 3-2-3-->
<h5>Permintaan Pemeriksaan Influenza B</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-3-2-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-3-2-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-3-2-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-3-2-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-3-2-3">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid/ili/ServiceRequest-Create-PermintaanPemeriksaanInfluenzaB-2.json}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-3-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-3-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-3-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 3-2-3-->

</div>
<!--END Part 3-->


<!--Part 4-->
### <div id="specimen">Step 4. Spesimen</div>

<div style="margin-left: 30px;">
<!--Part 4-1-->
<h4 style="font-weight: bold;">A. Spesimen Swab Tenggorok & Swab Hidung</h4>
<h5>Specimen Keadaan Baik</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-4-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-4-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-4-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-4-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-4-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-Specimen-Create-GoodCondition}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-4-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-4-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-4-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 4-1-->

<!--Part 4-2-->
<h5>Specimen Keadaan Tidak Baik</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-4-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-4-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-4-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-4-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-4-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-Specimen-Create-BadCondition}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-4-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-4-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-4-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 4-2-->

<!--Part 4-3-->
<h4 style="font-weight: bold;">B. Specimen Lainnya</h4>

<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-4-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-4-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-4-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-4-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-4-3">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-SARI-Specimen-Create-SpesimenLainnya}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-4-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>

</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-4-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>[none]</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-4-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 4-3-->
</div>
<!--END Part 4-->

<!--Part 5-->

### <div id="specimen">Step 5. Hasil Pemeriksaan Laboratorium</div>

<div style="margin-left: 30px;">
<!--Part 5-1-->
<h4 style="font-weight: bold;">COVID-19 PCR</h4>
<h5>COVID-19 PCR - Positif</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-5-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-5-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-5-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-5-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-5-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-Observation-Create-HasilPemeriksaanLab-Covid19}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-5-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-5-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-5-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 5-1-->

<!--Part 5-2-1-->
<h4 style="font-weight: bold;">B. Influenza A</h4>
<h5>Influenza A - Positif</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-5-2-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-5-2-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-5-2-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-5-2-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-5-2-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid-ILI-Observation-Create-HasilPemeriksaanLab-InfluenzaA-Positif}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-5-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-5-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-5-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 5-2-1-->

<!--Part 5-2-2-->
<h5>Influenza A - Subtype</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-5-2-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-5-2-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-5-2-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-5-2-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-5-2-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-ILI-Observation-Create-HasilPemeriksaanLab-InfluenzaA-Subtype}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-5-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-5-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-5-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 5-2-2-->

<!--Part 5-2-3-->
<h5>Influenza A - Invalid</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-5-2-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-5-2-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-5-2-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-5-2-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-5-2-3">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-ILI-Observation-Create-HasilPemeriksaanLab-InfluenzaA-Invalid}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-5-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-5-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-5-2-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 5-2-3-->

</div>

### <div id=""> Step 6. Laporan Hasil Pemeriksaan Laboratorium (Waktu Verifikasi Hasil)</div>

<div style="margin-left: 30px;">

<!--Part 6-1-->
<h4 style="font-weight: bold;">A. Covid 19</h4>
<h5>Covid 19 - Positif</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-6-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-6-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-6-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-6-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-6-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-ILI-DiagnosticReport-Create-Laporan-Covid19}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-6-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-6-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-6-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 6-1-->

<!--Part 6-2-->
<h4 style="font-weight: bold;">B. Influenza A</h4>
<h5>Influenza A - Positif</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-6-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-6-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-6-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-6-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-6-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-ILI-DiagnosticReport-Create-Laporan-InfluenzaA}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-6-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-6-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-6-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 6-2-->

<!--Part 6-3-->
<h5>Influenza A Subtype</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-6-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-6-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-6-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-6-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-6-3">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-ILI-DiagnosticReport-Create-Laporan-InfluenzaA-Subtype}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-6-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-6-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-6-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 6-3-->
</div>

### <div id=""> Step 7. Update Kunjungan Rawat Inap (Status Keluar)</div>

<div style="margin-left: 30px;">
<!--Part 7-2-->
<h4 style="font-weight: bold;">7.1. Diagnosis Akhir</h4>
<!--Part 7-2-1-->
<h5>Diagnosa Primer</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-7-2-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-7-2-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-7-2-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-7-2-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-7-2-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-SARI-Condition-Primary--Create-DiagnosaSaatMeninggalkanRS}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-7-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-7-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-7-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 7-2-1-->

<!--Part 7-2-2-->
<h5>Diagnosa Sekunder</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-7-2-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-7-2-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-7-2-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-7-2-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-7-2-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-SARI-Condition-Secondary--Create-DiagnosaSaatMeninggalkanRS}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-7-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-7-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-7-2-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 7-2-2-->
<!--END Part 7-2-->

<!--Part 7-1-1-->
<h4 style="font-weight: bold;">7.2. Status Keluar</h4>
<h5>7.1.1. Apabila Pasien dipulangkan</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-7-1-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-7-1-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-7-1-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-7-1-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-7-1-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid/SARI/Encounter-Update-PasienPulang.json}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-7-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-7-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-7-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 7-1-1-->

<!--Part 7-1-2-->
<h5>7.1.2. Apabila Pasien dirujuk</h5>
<h5>Update Status Kunjungan</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-7-1-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-7-1-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-7-1-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-7-1-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-7-1-2">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">
{{json:covid/SARI/Encounter-Update-PasienDirujuk.json}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-7-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-7-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-7-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 7-1-2-->

<!--Part 7-1-3-->
<h5>Create Permintaan Rujukan</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-7-1-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-7-1-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-7-1-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-7-1-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-7-1-3">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-SARI-ServiceRequest-Create-PermintaanRujukan}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-7-1-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-7-1-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-7-1-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 7-1-3-->


<h5>7.1.3. Apabila Pasien Meninggal</h5>
<!--Part 7-1-4-->
<h5>Update Status Kunjungan</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-7-1-4" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-7-1-4" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-7-1-4" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-7-1-4" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-7-1-4">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid/SARI/Encounter-Update-PasienMeninggal.json}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-7-1-4" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-7-1-4" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-7-1-4" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 7-1-4-->

<!--Part 7-1-5-->
<h5>Tanggal Meninggal</h5>
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-7-1-5" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-7-1-5" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-7-1-5" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-7-1-5" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-7-1-5">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-SARI-Observation-Create-TanggalMeninggal}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-7-1-5" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-7-1-5" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-7-1-5" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 7-1-5-->

</div>


### <div id="">Step 8. Kuesioner Kasus SARI</div>

<div style="margin-left: 30px;">

<!--Part 8-1-->
<ul class="nav nav-tabs" role="tablist">
<li role="presentation" class="active">
<a href="#example-8-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
</li>
<li role="presentation">
<a href="#data-8-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
</li>
<li role="presentation">
<a href="#variabel-8-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
</li>
<li role="presentation">
<a href="#valueset-8-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
</li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
<div role="tabpanel" class="tab-pane active" id="example-8-1">
<div style="background: #F6F8F8;border: 1px solid #e8edee;">{{json:covid-SARI-Composition-Create-Kuesioner-Kasus-SARI}}
</div>
</div>

<div role="tabpanel" class="tab-pane" id="data-8-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-8-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="valueset-8-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
[none]
</div>
</div>
</div>
<br>
<!--END Part 8-1-->

</div>