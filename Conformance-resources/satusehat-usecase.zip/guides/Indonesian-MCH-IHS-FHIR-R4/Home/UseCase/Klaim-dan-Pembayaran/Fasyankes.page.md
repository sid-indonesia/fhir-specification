## <b> I. Fasyankes </b> 
*Last Updated: 2023/09/17*

<p>
Data klinis baik pada pasien rawat jalan maupun rawat inap akan selalu berisikan data kunjungan pasien yang disimpan dalam resource Encounter. Data-data kunjungan pasien yang direkam meliputi kapan pertemuan tersebut mulai dan selesai, siapa tenaga kesehatan yang melayani, siapa subjek dari pelayanannya, dan informasi pendukung lainnya. Encounter.id data kunjungan ini akan dilampirkan pada beberapa resource seperti data klaim BPJS (Claim), data pembayaran (ChargeItem), dan data pengajuan Surat Eligibilitas Peserta (CoverageEligibilityRequest).
</p>
<p>
Tahapan alur integrasi dan resource yang digunakan untuk proses klaim dapat dilihat pada gambar dibawah ini:</p>
<center>
{{render:hf-integrasi-bpjs-satusehat-pengajuan-klaim}}

*Gambar 3. Skema Pengajuan Klaim BPJS oleh Fasyankes*
</center>

### <b>Step 1. Pengajuan Surat Eligibilitas Peserta (SEP)</b>
<div style="margin-left: 30px;">
<p>Pasien yang ditanggung oleh BPJS Kesehatan yang datang berkunjung ke Rumah Sakit, baik pasien yang telah dirujuk dari faskes lain ataupun pasien yang masuk melalui jalur lain, akan mendapatkan Surat Eligibilitas Peserta atau yang sering disebut dengan SEP.
</p>
<!--Pada dasarnya SEP dapat dibuat oleh rumah sakit melalui 2 metode ini:
1. Melalui aplikasi VKLAIM yang disediakan oleh pihak BPJS
2. Melalui SIMRS Rumah Sakit itu sendiri, dengan syarat SIMRS tersebut sudah bridging dengan Web Service VKLAIM.-->
<p>Pengajuan SEP dapat dilakukan oleh fasyankes dengan mengirimkan resource CoverageEligibilityRequest ke SATUSEHAT dengan format dibawah ini:
</p>

<!--Part fasyankes-1-1 Pengajuan No. SEP BPJS-->
<h4 style="font-weight: bold;">Pengajuan No. SEP BPJS</h4>
	
<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active">
        <a href="#example-fasyankes-1-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
    </li>
    <li role="presentation">
        <a href="#data-fasyankes-1-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
    </li>
    <li role="presentation">
        <a href="#variabel-fasyankes-1-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
    </li>
    <li role="presentation">
        <a href="#valueset-fasyankes-1-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
    </li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
    <div role="tabpanel" class="tab-pane active" id="example-fasyankes-1-1">
        <div style="background: #F6F8F8;border: 1px solid #e8edee;">
        {{json:HealthFinancing-01KlaimBPJS-CoverageEligibilityRequest-Create-Pengajuan-SEP}}
        </div>
    </div>

<div role="tabpanel" class="tab-pane" id="data-fasyankes-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<pre style="background: #F6F8F8;border: 1px solid #e8edee; color: maroon;">
{
    "resourceType": "CoverageEligibilityRequest",
    "status": "active",
    "priority": {
        "coding": [
            {
                "code": "normal"
            }
        ]
    },
    "purpose": [
        "validation",
        "benefits"
    ],
    "patient": {
        "reference": "Patient/<strong style="color:#00a7ff">&lcub;&lcub;PATIENT_IHS_NUMBER&rcub;&rcub;</strong>",
		"display": "<strong style="color:#00a7ff">&lcub;&lcub;PATIENT_NAME&rcub;&rcub;</strong>"
    },
    "servicedDate": "<strong style="color:#00a7ff">&lcub;&lcub;SERVICE_DATE&rcub;&rcub;</strong>",
    "created": "<strong style="color:#00a7ff">&lcub;&lcub;COVERAGEELIGIBILITYREQUEST_CREATED_DATETIME&rcub;&rcub;</strong>",
    "enterer": {
        "reference": "Practitioner/<strong style="color:#00a7ff">&lcub;&lcub;PRACTITIONER_IHS_NUMBER&rcub;&rcub;</strong>",
		"display": "<strong style="color:#00a7ff">&lcub;&lcub;PRACTITIONER_NAME&rcub;&rcub;</strong>"
    },
    "provider": {
        "reference": "Organization/<strong style="color:#00a7ff">&lcub;&lcub;PROVIDER_FACILITY_IHS_NUMBER&rcub;&rcub;</strong>",
		"display": "<strong style="color:#00a7ff">&lcub;&lcub;PROVIDER_FACILITY_NAME&rcub;&rcub;</strong>"
    },
    "insurer": {
        "reference": "Organization/<strong style="color:#00a7ff">&lcub;&lcub;INSURER_FACILITY_IHS_NUMBER&rcub;&rcub;</strong>",
		"display": "<strong style="color:#00a7ff">&lcub;&lcub;INSURER_FACILITY_NAME&rcub;&rcub;</strong>"
    },
    "facility": {
        "reference": "Location/<strong style="color:#00a7ff">&lcub;&lcub;COVERAGEELIGIBILITYREQUEST_LOCATION_ID&rcub;&rcub;</strong>",
		"display": "<strong style="color:#00a7ff">&lcub;&lcub;COVERAGEELIGIBILITYREQUEST_LOCATION_NAME&rcub;&rcub;</strong>"
    },
    "insurance": [
        {
            "coverage": {
                "reference": "Coverage/<strong style="color:#00a7ff">&lcub;&lcub;COVERAGE_ID&rcub;&rcub;</strong>"
            }
        }
    ],
    "item": [
        {
            "category": {
                "coding": [
                    {
                        "system": "http://hl7.org/fhir/sid/icd-10",
                        "code": "<strong style="color:#00a7ff">&lcub;&lcub;DIAGNOSIS_ICD_CODE&rcub;&rcub;</strong>",
                        "display": "<strong style="color:#00a7ff">&lcub;&lcub;DIAGNOSIS_ICD_DISPLAY&rcub;&rcub;</strong>"
                    }
                ]
            }
        }
    ]
}
</pre>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-fasyankes-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">

| Variabel                       | Deskripsi |
| ------------------------------ | --------- |
| __PATIENT_IHS_NUMBER__      			| SATUSEHAT ID Number untuk Pasien |
| __PATIENT_NAME__           			| Nama Pasien 	|
| __SERVICE_DATE__						| Tanggal pelayanan kesehatan diberikan |
| __COVERAGEELIGIBILITYREQUEST_CREATED_DATETIME__ | Tanggal dan waktu pengajuan SEP ini dilakukan (dibuat oleh sistem)	|
| __PRACTITIONER_IHS_NUMBER__ 			| SATUSEHAT ID untuk staff fasyankes yang mengajukan SEP|
| __PRACTITIONER_NAME__					| Nama staff fasyankes yang mengajukan SEP|
| __PROVIDER_FACILITY_IHS_NUMBER__   			| SATUSEHAT ID untuk fasyankes yang mengajukan SEP|
| __PROVIDER_FACILITY_NAME__           			| Nama fasyankes yang mengajukan SEP|
| __INSURER_FACILITY_IHS_NUMBER__   			| SATUSEHAT ID untuk pihak verifikator SEP (Default: BPJS Kesehatan) |
| __INSURER_FACILITY_NAME__           			| Nama pihak verifikator SEP (Default: BPJS Kesehatan) |
| __COVERAGEELIGIBILITYREQUEST_LOCATION_ID__   				| ID lokasi fasyankes pengajuan SEP |
| __COVERAGEELIGIBILITYREQUEST_LOCATION_NAME__   					| Nama lokasi fasyankes pengajuan SEP |
| __COVERAGE_ID__					| ID data Kepesertaan BPJS	|
| __DIAGNOSIS_ICD_CODE__    		| Kode ICD-10 untuk diagnosa penyakit yang diderita pasien|
| __DIAGNOSIS_ICD_DISPLAY__ 	| Deskripsi ICD-10 untuk diagnosa penyakit yang diderita pasien|

> `CATATAN:` <br>
> __(*)__: Jenis data yang memiliki terminologi spesifik. Kamus terminologi bisa ditemukan pada tab "ValueSet"
</div>
		
<div role="tabpanel" class="tab-pane" id="valueset-fasyankes-1-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
			<div>
				[none]
			</div>
		</div>
	</div>
<br>
<!--END Part fasyankes-1-1-->

<!--Part fasyankes-1-2 Informasi Tambahan Data Medis-->
<h4 style="font-weight: bold;">Data Medis (Informasi Tambahan)</h4>
Pada proses pengajuan No. SEP, informasi pendukung yang berhubungan dengan layanan medis pasien juga perlu dilampirkan. Data medis yang dimaksud adalah:
1. Jenis Pelayanan: Termasuk jenis pelayanan rawat jalan atau rawat inap
2. Asal Rujukan: Berasal dari Fasilitas Kesehatan Tingkat 1 atau Fasilitas Kesehatan Tingkat 2
3. Tanggal Rujukan
4. Nomor Rujukan: Id 
5. Pemberi pelayanan kesehatan (PPK) Rujukan: Fasyankes yang dirujuk

 Informasi pendukung ini akan disimpan dalam resource QuestionnaireResponse.
Kolom CoverageEligibilityRequest.supportingInfo.information pada contoh diatas akan mereferensi ke QuestionnaireResponse.id.

<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active">
        <a href="#example-fasyankes-1-2" aria-controls="example" role="tab" data-toggle="tab">Example</a>
    </li>
    <li role="presentation">
        <a href="#data-fasyankes-1-2" aria-controls="data" role="tab" data-toggle="tab">Template</a>
    </li>
    <li role="presentation">
        <a href="#variabel-fasyankes-1-2" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
    </li>
    <li role="presentation">
        <a href="#valueset-fasyankes-1-2" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
    </li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
    <div role="tabpanel" class="tab-pane active" id="example-fasyankes-1-2">
        <pre style="background: #F6F8F8;border: 1px solid #e8edee; color: maroon;">
        {{json:QuestionnaireResponse-Create-Data-Pendukung-Medis-1}}
        </pre>
    </div>
    
<div role="tabpanel" class="tab-pane" id="data-fasyankes-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-fasyankes-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>
		
<div role="tabpanel" class="tab-pane" id="valueset-fasyankes-1-2" style="border: 1px solid #e8edee; padding: 15px 10px;">
			<div>
				[none]
			</div>
		</div>
	</div>
<br>
<!--END Part fasyankes-1-2-->

<!--Part fasyankes-1-3-->
<h4 style="font-weight: bold;">Respon No. Surat Eligibilitas Pelayanan (SEP) BPJS</h4>
Setelah fasyankes mengirimkan data pengajuan SEP BPJS ke SATUSEHAT, sistem BPJS Kesehatan akan melakukan verifikasi terhadap resource CoverageEligibilityRequest secara real-time. SATUSEHAT otomatis akan mengirimkan respon dari data pengajuan SEP tersebut dalam resource CoverageEligibilityResponse.
Apabila hasil verifikasi berhasil, maka No. SEP akan tergenerate dan dilampirkan pada resource CoverageEligibilityResponse. Berhubung SEP merupakan syarat utama atau surat jaminan pasien bisa menggunakan fasilitas BPJS, oleh karena itu apabila hasil verifikasi gagal, maka No. SEP tidak akan terbentuk dan secara otomatis pasien tidak bisa menggunakan fasilitas BPJS. Status hasil verifikasi SEP bisa dilihat pada kolom CoverageEligibilityResponse.outcome. 
	
<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active">
        <a href="#example-fasyankes-1-3" aria-controls="example" role="tab" data-toggle="tab">Example</a>
    </li>
    <li role="presentation">
        <a href="#data-fasyankes-1-3" aria-controls="data" role="tab" data-toggle="tab">Template</a>
    </li>
    <li role="presentation">
        <a href="#variabel-fasyankes-1-3" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
    </li>
    <li role="presentation">
        <a href="#valueset-fasyankes-1-3" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
    </li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
    <div role="tabpanel" class="tab-pane active" id="example-fasyankes-1-3">
        <div style="background: #F6F8F8;border: 1px solid #e8edee;">
        {{json:01KlaimBPJS-CoverageEligibilityResponse-Create-Verifikasi-SEP}}
        </div>
    </div>
    
<div role="tabpanel" class="tab-pane" id="data-fasyankes-1-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
<pre style="background: #F6F8F8;border: 1px solid #e8edee; color: maroon;">
{
    "resourceType": "CoverageEligibilityResponse",
    "status": "active",
    "purpose": [
        "validation",
        "benefits"
    ],
    "patient": {
		"reference": "Patient/<strong style="color:#00a7ff">&lcub;&lcub;PATIENT_IHS_NUMBER&rcub;&rcub;</strong>",
		"display": "<strong style="color:#00a7ff">&lcub;&lcub;PATIENT_NAME&rcub;&rcub;</strong>"
    },
     "servicedDate": "<strong style="color:#00a7ff">&lcub;&lcub;SERVICE_DATE&rcub;&rcub;</strong>",
    "created": "<strong style="color:#00a7ff">&lcub;&lcub;COVERAGEELIGIBILITYRESPONSE_CREATED_DATETIME&rcub;&rcub;</strong>",
    "request": {
        "reference": "CoverageEligibilityRequest/&lcub;&lcub;COVERAGEELIGIBILITYREQUEST_ID&rcub;&rcub;"
    },
    "outcome": "&lcub;&lcub;HASIL_VERIFIKASI&rcub;&rcub;",
    "insurer": {
         "reference": "Organization/<strong style="color:#00a7ff">&lcub;&lcub;INSURER_FACILITY_IHS_NUMBER&rcub;&rcub;</strong>",
		"display": "<strong style="color:#00a7ff">&lcub;&lcub;INSURER_FACILITY_NAME&rcub;&rcub;</strong>"
    },
    "insurance": [
        {
            "coverage": {
                 "reference": "Coverage/<strong style="color:#00a7ff">&lcub;&lcub;COVERAGE_ID&rcub;&rcub;</strong>"
            },
            "inforce": true,
            "item": [
                {
                    "category": {
                        "coding": [
                            {
                                "system": "http://terminology.hl7.org/CodeSystem/ex-benefitcategory",
                                "code": "<strong style="color:#00a7ff">&lcub;&lcub;COVERAGE_CATEGORY_CODE&rcub;&rcub;</strong>",
                                "display": "<strong style="color:#00a7ff">&lcub;&lcub;COVERAGE_CATEGORY_DISPLAY&rcub;&rcub;</strong>"
                            }
                        ]
                    },
                    "network": {
                        "coding": [
                            {
                                "system": "http://terminology.hl7.org/CodeSystem/benefit-network",
                                "code": "in"
                            }
                        ]
                    },
                    "unit": {
                        "coding": [
                            {
                                "system": "http://terminology.hl7.org/CodeSystem/benefit-unit",
                                "code": "individual"
                            }
                        ]
                    },
                    "term": {
                        "coding": [
                            {
                                "system": "http://terminology.hl7.org/CodeSystem/benefit-term",
                                "code": "annual"
                            }
                        ]
                    },
                    "benefit": [
                        {
                            "type": {
                                "coding": [
                                    {
                                        "code": "benefit"
                                    }
                                ]
                            },
                            "allowedMoney": {
                                "value": <strong style="color:#00a7ff">&lcub;&lcub;AMOUNT1_VALUE&rcub;&rcub;</strong>,
                                "currency": "IDR"
                            }
                        },
                        {
                            "type": {
                                "coding": [
                                    {
                                        "code": "copay-maximum"
                                    }
                                ]
                            },
                            "allowedMoney": {
                                "value": <strong style="color:#00a7ff">&lcub;&lcub;AMOUNT2_VALUE&rcub;&rcub;</strong>,
                                "currency": "IDR"
                            }
                        },
                        {
                            "type": {
                                "coding": [
                                    {
                                        "code": "copay-percent"
                                    }
                                ]
                            },
                            "allowedUnsignedInt": <strong style="color:#00a7ff">&lcub;&lcub; AMOUNT1_PERCENTAGE&rcub;&rcub;</strong>
                        }
                    ]
                }
            ]
        }
    ]
}
</div>
</pre>

<div role="tabpanel" class="tab-pane" id="variabel-fasyankes-1-3" style="border: 1px solid #e8edee; padding: 15px 10px;">

| Variabel                       | Deskripsi |
| ------------------------------ | --------- |
| __PATIENT_IHS_NUMBER__      			| SATUSEHAT ID Number untuk Pasien |
| __PATIENT_NAME__           			| Nama Pasien 	|
| __SERVICE_DATE__						| Estimasi tanggal  pelayanan kesehatan diberikan |
| __COVERAGEELIGIBILITYRESPONSE_CREATED_DATETIME__ | Tanggal dan waktu verifikasi SEP ini dilakukan (dibuat oleh sistem)	|
| __COVERAGEELIGIBILITYREQUEST_ID__   				| ID CoverageEligibilityRequest data pengajuan SEP |
| __INSURER_FACILITY_IHS_NUMBER__   			| SATUSEHAT ID untuk pihak verifikator SEP (Default: BPJS Kesehatan) |
| __INSURER_FACILITY_NAME__           			| Nama pihak verifikator SEP (Default: BPJS Kesehatan) |
| __COVERAGE_ID__					| ID data Kepesertaan BPJS	|
| __COVERAGE_CATEGORY_CODE__		| Kode kategori pelayanan kesehatan yang bisa diklaim oleh pasien BPJS|
| __COVERAGE_CATEGORY_DISPLAY__ 	| Deskripsi kategori pelayanan kesehatan yang bisa diklaim oleh pasien BPJS|
| __AMOUNT1_VALUE__					| Biaya maksimum yang diperbolehkan untuk klaim (dalam rupiah)	|
| __AMOUNT2_VALUE__					| Pembayaran per layanan (dalam rupiah)	|
| __AMOUNT1_PERCENTAGE__			| Persentase pembayaran per layanan |
</div>
		
<div role="tabpanel" class="tab-pane" id="valueset-fasyankes-1-3" style="border: 1px solid #e8edee; padding: 15px 10px;">
			<div>
				[none]
			</div>
		</div>
	</div>
<br>
<!--END Part fasyankes-1-3-->
</div>

### <b>Step 2. Pengiriman Data Klinis dan Pembayaran oleh Fasyankes</b>
<div style="margin-left: 30px;">
<p>Fasyankes yang sudah terintegrasi dengan SATUSEHAT akan mengirimkan data klinis dan pembayaran untuk pasien rawat jalan/ rawat inap ke SATUSEHAT. Data-data inilah yang nantinya akan digunakan oleh BPJS sebagai acuan dalam melakukan verifikasi klaim BPJS.</p>
<p>Data klinis baik pada pasien rawat jalan maupun rawat inap akan selalu berisikan data kunjungan pasien yang disimpan dalam resource Encounter. Data-data kunjungan pasien yang direkam meliputi kapan pertemuan tersebut mulai dan selesai, siapa tenaga kesehatan yang melayani, siapa subjek dari pelayanannya, dan informasi pendukung lainnya. Encounter.id data kunjungan ini akan dilampirkan pada beberapa resource seperti data klaim BPJS (Claim), data pembayaran (ChargeItem), dan data pengajuan Surat Eligibilitas Pasien (CoverageEligibilityRequest).
</p>

<!--Part 2-1 Pendaftaran Kunjungan Pasien Rawat Inap-->
<h4 style="font-weight: bold;">Pendaftaran Kunjungan Pasien Rawat Inap</h4>
	
<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active">
        <a href="#example-2-1" aria-controls="example" role="tab" data-toggle="tab">Example</a>
    </li>
    <li role="presentation">
        <a href="#data-2-1" aria-controls="data" role="tab" data-toggle="tab">Template</a>
    </li>
    <li role="presentation">
        <a href="#variabel-2-1" aria-controls="variabel" role="tab" data-toggle="tab">Placeholder Variable</a>
    </li>
    <li role="presentation">
        <a href="#valueset-2-1" aria-controls="variabel" role="tab" data-toggle="tab">ValueSet</a>
    </li>
</ul>

<!-- Tab panes -->
<div class="tab-content snippet">
    <div role="tabpanel" class="tab-pane active" id="example-2-1">
        <div style="background: #F6F8F8;border: 1px solid #e8edee;">
        {{json:HealthFinancing-01KlaimBPJS-Encounter-Create-Inpatient-1}}
        </div>
    </div>
    
<div role="tabpanel" class="tab-pane" id="data-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>

<div role="tabpanel" class="tab-pane" id="variabel-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
<div>
#tba
</div>
</div>
		
<div role="tabpanel" class="tab-pane" id="valueset-2-1" style="border: 1px solid #e8edee; padding: 15px 10px;">
			<div>
				[none]
			</div>
		</div>
	</div>
<br>
<!--END Part 2-1-->

<!--#tba Other FHIR Resources</i> (data klinis), Account, ChargeItem, Invoice-->

> `CATATAN:`
> Proses pengiriman data pasien rawat jalan ke SATUSEHAT secara detail dapat dilihat dalam dokumen <a href="https://drive.google.com/file/d/1fMc1qQriLExDTVPbRQd0hEvTgfWjjCgP/view?usp=share_link" target="_blank">Playbook Resume Medis Rawat Jalan</a>.
</div>

## Referensi:

<table style="background-color: #f6f8f8; border-radius: 10px;">
    <tr>
         <td style="padding: 10px 20px; width: 33%; vertical-align: top;">Postman Klaim dan Pembayaran</td>
        <td style="padding: 10px 20px; ; width: 33%; vertical-align: top;">Playbook Klaim dan Pembayaran (Fasyankes)</td>
        <td style="padding: 10px 20px; ; width: 33%; vertical-align: top;">Postman Resume Medis Rawat Jalan SATUSEHAT</td>
    </tr>
    <tr>
        <td style="padding: 10px 20px; ;"><div style="background-color: lightblue; display: inline-block; border-radius: 4px; cursor: pointer; height: 32px; border: none; width: 123px; background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI4IiBoZWlnaHQ9IjMyIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMjgiIGhlaWdodD0iMzIiIHJ4PSI0IiBmaWxsPSIjRkY2QzM3Ii8+PHBhdGggZD0iTTEyIDEwLjg4M2EuNS41IDAgMCAxIC43NTctLjQyOWw4LjUyOCA1LjExN2EuNS41IDAgMCAxIDAgLjg1OGwtOC41MjggNS4xMTdhLjUuNSAwIDAgMS0uNzU3LS40M1YxMC44ODRaTTI3Ljg4OSAyMC41MDloMS41OHYtMy4xOTdoMS42MTFsMS43MTMgMy4xOTdoMS43NjRsLTEuODg3LTMuNDZjMS4wMjctLjQxNCAxLjU2OC0xLjI5MiAxLjU2OC0yLjQ3NyAwLTEuNjY2LTEuMDc0LTIuNzktMy4wNzctMi43OWgtMy4yNzN2OC43MjdaTTI5LjQ2OCAxNnYtMi44OThoMS40NWMxLjE4IDAgMS43MDguNTQxIDEuNzA4IDEuNDcgMCAuOTMtLjUyOCAxLjQyOC0xLjcgMS40MjhIMjkuNDdaTTM5Ljc5NyAxNy43NTZjMCAuOTk3LS43MTIgMS40OTEtMS4zOTQgMS40OTEtLjc0MSAwLTEuMjM1LS41MjQtMS4yMzUtMS4zNTV2LTMuOTI5aC0xLjU0M3Y0LjE2OGMwIDEuNTcyLjg5NSAyLjQ2MyAyLjE4MiAyLjQ2My45OCAwIDEuNjctLjUxNiAxLjk2OS0xLjI0OWguMDY4djEuMTY0aDEuNDk1di02LjU0NmgtMS41NDJ2My43OTNaTTQ0LjQ2OCAxNi42NzNjMC0uOTQ2LjU3MS0xLjQ5MSAxLjM4NS0xLjQ5MS43OTcgMCAxLjI3NC41MjQgMS4yNzQgMS4zOTd2My45M2gxLjU0M1YxNi4zNGMuMDA0LTEuNTY4LS44OS0yLjQ2My0yLjI0MS0yLjQ2My0uOTggMC0xLjY1NC40NjktMS45NTIgMS4xOTdINDQuNHYtMS4xMTJoLTEuNDc0djYuNTQ2aDEuNTQydi0zLjgzNlpNNTMuMjE1IDIwLjUwOWgxLjU0MnYtNi41NDZoLTEuNTQydjYuNTQ2Wm0uNzc1LTcuNDc1Yy40OSAwIC44OTEtLjM3NS44OTEtLjgzNSAwLS40NjUtLjQtLjg0LS44OS0uODQtLjQ5NSAwLS44OTUuMzc1LS44OTUuODQgMCAuNDYuNC44MzUuODk0LjgzNVpNNTcuODg2IDE2LjY3M2MwLS45NDYuNTcxLTEuNDkxIDEuMzg1LTEuNDkxLjc5NyAwIDEuMjc0LjUyNCAxLjI3NCAxLjM5N3YzLjkzaDEuNTQzVjE2LjM0Yy4wMDQtMS41NjgtLjg5LTIuNDYzLTIuMjQxLTIuNDYzLS45OCAwLTEuNjU0LjQ2OS0xLjk1MiAxLjE5N2gtLjA3N3YtMS4xMTJoLTEuNDc0djYuNTQ2aDEuNTQydi0zLjgzNlpNNjYuNzAxIDIwLjUwOWgxLjU4MXYtMi45NWgxLjY3YzIuMDE2IDAgMy4wOTgtMS4yMSAzLjA5OC0yLjg4OSAwLTEuNjY2LTEuMDctMi44ODktMy4wNzYtMi44ODlINjYuN3Y4LjcyOFptMS41ODEtNC4yNXYtMy4xNTdoMS40NDljMS4xODQgMCAxLjcwOS42NCAxLjcwOSAxLjU2OSAwIC45MjgtLjUyNSAxLjU4OS0xLjcgMS41ODloLTEuNDU4Wk03Ny4xMTcgMjAuNjM2YzEuOTE3IDAgMy4xMzYtMS4zNSAzLjEzNi0zLjM3NSAwLTIuMDI4LTEuMjE5LTMuMzgzLTMuMTM2LTMuMzgzLTEuOTE4IDAtMy4xMzYgMS4zNTUtMy4xMzYgMy4zODMgMCAyLjAyNCAxLjIxOCAzLjM3NSAzLjEzNiAzLjM3NVptLjAwOC0xLjIzNWMtMS4wNiAwLTEuNTgtLjk0Ny0xLjU4LTIuMTQ0cy41Mi0yLjE1NiAxLjU4LTIuMTU2YzEuMDQ0IDAgMS41NjQuOTU5IDEuNTY0IDIuMTU2cy0uNTIgMi4xNDQtMS41NjQgMi4xNDRaTTg2LjczNiAxNS42OTNjLS4yMTMtMS4xMDgtMS4xLTEuODE1LTIuNjM0LTEuODE1LTEuNTc2IDAtMi42NS43NzUtMi42NDYgMS45ODYtLjAwNC45NTQuNTg0IDEuNTg1IDEuODQgMS44NDVsMS4xMTcuMjM0Yy42MDEuMTMyLjg4My4zNzUuODgzLjc0NiAwIC40NDctLjQ4Ni43ODQtMS4yMi43ODQtLjcwNyAwLTEuMTY3LS4zMDctMS4yOTktLjg5NWwtMS41MDQuMTQ1Yy4xOTIgMS4yMDIgMS4yMDEgMS45MTMgMi44MDggMS45MTMgMS42MzYgMCAyLjc5MS0uODQ4IDIuNzk1LTIuMDg4LS4wMDQtLjkzMy0uNjA1LTEuNTA0LTEuODQtMS43NzJsLTEuMTE3LS4yNGMtLjY2NS0uMTQ4LS45MjktLjM3OC0uOTI1LS43NTgtLjAwNC0uNDQzLjQ4Ni0uNzUgMS4xMy0uNzUuNzExIDAgMS4wODYuMzg4IDEuMjA2LjgxOWwxLjQwNi0uMTU0Wk05MS40MTcgMTMuOTYzaC0xLjI5MXYtMS41NjhoLTEuNTQzdjEuNTY4aC0uOTI5djEuMTkzaC45M3YzLjY0Yy0uMDEgMS4yMzEuODg1IDEuODM2IDIuMDQ0IDEuODAyYTMuMSAzLjEgMCAwIDAgLjkwOC0uMTUzbC0uMjYtMS4yMDZjLS4wODUuMDItLjI2LjA2LS40NTEuMDYtLjM4OCAwLS43LS4xMzctLjctLjc2di0zLjM4M2gxLjI5MnYtMS4xOTNaTTkyLjcwNyAyMC41MDloMS41NDN2LTMuOThjMC0uODA2LjUzNy0xLjM1MSAxLjIwMS0xLjM1MS42NTIgMCAxLjEuNDM4IDEuMSAxLjExMnY0LjIxOWgxLjUxM3YtNC4wODNjMC0uNzM3LjQzOS0xLjI0OCAxLjE4NC0xLjI0OC42MjIgMCAxLjExNy4zNjYgMS4xMTcgMS4xNzZ2NC4xNTVoMS41NDd2LTQuMzk0YzAtMS40NjItLjg0NC0yLjIzNy0yLjA0Ni0yLjIzNy0uOTUgMC0xLjY3NS40NjktMS45NjQgMS4xOTdoLS4wNjljLS4yNTEtLjc0MS0uODg2LTEuMTk3LTEuNzY4LTEuMTk3LS44NzggMC0xLjUzNC40NTEtMS44MDcgMS4xOTdoLS4wNzZ2LTEuMTEyaC0xLjQ3NXY2LjU0NlpNMTA1LjM2IDIwLjY0YzEuMDI3IDAgMS42NDEtLjQ4IDEuOTIyLTEuMDNoLjA1MXYuODk5aDEuNDgzdi00LjM4MWMwLTEuNzMtMS40MS0yLjI1LTIuNjU5LTIuMjUtMS4zNzYgMC0yLjQzMy42MTQtMi43NzQgMS44MDdsMS40NC4yMDRjLjE1NC0uNDQ3LjU4OC0uODMgMS4zNDItLjgzLjcxNiAwIDEuMTA4LjM2NiAxLjEwOCAxLjAxdi4wMjVjMCAuNDQzLS40NjQuNDY0LTEuNjE5LjU4OC0xLjI3LjEzNi0yLjQ4NC41MTUtMi40ODQgMS45OSAwIDEuMjg3Ljk0MiAxLjk2OSAyLjE5IDEuOTY5Wm0uNDAxLTEuMTMzYy0uNjQ0IDAtMS4xMDQtLjI5NC0xLjEwNC0uODYgMC0uNTkzLjUxNi0uODQgMS4yMDYtLjkzOC40MDUtLjA1NiAxLjIxNC0uMTU4IDEuNDE1LS4zMnYuNzcxYzAgLjczLS41ODggMS4zNDctMS41MTcgMS4zNDdaTTExMS45MSAxNi42NzNjMC0uOTQ2LjU3MS0xLjQ5MSAxLjM4NS0xLjQ5MS43OTcgMCAxLjI3NC41MjQgMS4yNzQgMS4zOTd2My45M2gxLjU0M1YxNi4zNGMuMDA0LTEuNTY4LS44OTEtMi40NjMtMi4yNDItMi40NjMtLjk4IDAtMS42NTMuNDY5LTEuOTUyIDEuMTk3aC0uMDc2di0xLjExMmgtMS40NzV2Ni41NDZoMS41NDN2LTMuODM2WiIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==');" onclick="https://drive.google.com/file/d/1cGWaQaU5ZjR-tThjjKDPkO9LTTevEzDq/view?usp=sharing"></div></td>
        <td style="padding: 10px 20px; ;"><div style="display: inline-block; border-radius: 4px; cursor: pointer; height: 32px; border: none; width: 123px; background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMTI1IiB6b29tQW5kUGFuPSJtYWduaWZ5IiB2aWV3Qm94PSIwIDAgOTMuNzUgMzAuMDAwMDAxIiBoZWlnaHQ9IjQwIiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2ZXJzaW9uPSIxLjAiPjxkZWZzPjxnLz48Y2xpcFBhdGggaWQ9ImE3ZDJlMzRmNmEiPjxwYXRoIGQ9Ik0gMS45NTcwMzEgMS4yNDYwOTQgTCA5MS45Njg3NSAxLjI0NjA5NCBMIDkxLjk2ODc1IDIzLjg3ODkwNiBMIDEuOTU3MDMxIDIzLjg3ODkwNiBaIE0gMS45NTcwMzEgMS4yNDYwOTQgIiBjbGlwLXJ1bGU9Im5vbnplcm8iLz48L2NsaXBQYXRoPjxjbGlwUGF0aCBpZD0iNzBhYjc4ZGEzNiI+PHBhdGggZD0iTSA0LjE0MDYyNSAxLjI0NjA5NCBMIDg5LjYwOTM3NSAxLjI0NjA5NCBDIDkwLjgxNjQwNiAxLjI0NjA5NCA5MS43OTI5NjkgMi4yMjI2NTYgOTEuNzkyOTY5IDMuNDI5Njg4IEwgOTEuNzkyOTY5IDIxLjUxOTUzMSBDIDkxLjc5Mjk2OSAyMi43MjY1NjIgOTAuODE2NDA2IDIzLjcwMzEyNSA4OS42MDkzNzUgMjMuNzAzMTI1IEwgNC4xNDA2MjUgMjMuNzAzMTI1IEMgMi45MzM1OTQgMjMuNzAzMTI1IDEuOTU3MDMxIDIyLjcyNjU2MiAxLjk1NzAzMSAyMS41MTk1MzEgTCAxLjk1NzAzMSAzLjQyOTY4OCBDIDEuOTU3MDMxIDIuMjIyNjU2IDIuOTMzNTk0IDEuMjQ2MDk0IDQuMTQwNjI1IDEuMjQ2MDk0ICIgY2xpcC1ydWxlPSJub256ZXJvIi8+PC9jbGlwUGF0aD48Y2xpcFBhdGggaWQ9IjM3ODA5ZDFmZWEiPjxwYXRoIGQ9Ik0gMTYuMTEzMjgxIDcuMjA3MDMxIEwgMTcuOTU3MDMxIDcuMjA3MDMxIEwgMTcuOTU3MDMxIDkuMDI3MzQ0IEwgMTYuMTEzMjgxIDkuMDI3MzQ0IFogTSAxNi4xMTMyODEgNy4yMDcwMzEgIiBjbGlwLXJ1bGU9Im5vbnplcm8iLz48L2NsaXBQYXRoPjxjbGlwUGF0aCBpZD0iMzQ1YzAxZDI0ZiI+PHBhdGggZD0iTSAxMC42Nzk2ODggNy4xOTkyMTkgTCAxNy45NTcwMzEgNy4xOTkyMTkgTCAxNy45NTcwMzEgMTcuMzkwNjI1IEwgMTAuNjc5Njg4IDE3LjM5MDYyNSBaIE0gMTAuNjc5Njg4IDcuMTk5MjE5ICIgY2xpcC1ydWxlPSJub256ZXJvIi8+PC9jbGlwUGF0aD48L2RlZnM+PGcgY2xpcC1wYXRoPSJ1cmwoI2E3ZDJlMzRmNmEpIj48ZyBjbGlwLXBhdGg9InVybCgjNzBhYjc4ZGEzNikiPjxwYXRoIGZpbGw9IiM0N2IwOGIiIGQ9Ik0gMS45NTcwMzEgMS4yNDYwOTQgTCA5MS45Njg3NSAxLjI0NjA5NCBMIDkxLjk2ODc1IDIzLjg3ODkwNiBMIDEuOTU3MDMxIDIzLjg3ODkwNiBaIE0gMS45NTcwMzEgMS4yNDYwOTQgIiBmaWxsLW9wYWNpdHk9IjEiIGZpbGwtcnVsZT0ibm9uemVybyIvPjwvZz48L2c+PGcgY2xpcC1wYXRoPSJ1cmwoIzM3ODA5ZDFmZWEpIj48cGF0aCBmaWxsPSIjZmZmZmZmIiBkPSJNIDE2LjEzNjcxOSA3LjIwNzAzMSBMIDE2LjE5OTIxOSA3LjIwNzAzMSBMIDE2LjI3MzQzOCA3LjIzNDM3NSBMIDE2LjM1MTU2MiA3LjI2NTYyNSBMIDE3Ljg5MDYyNSA4Ljc2NTYyNSBMIDE3Ljk1NzAzMSA4LjgyODEyNSBMIDE3Ljk1NzAzMSA5LjAwNzgxMiBMIDE2LjEzNjcxOSA5LjAwNzgxMiBMIDE2LjEzNjcxOSA3LjIwNzAzMSAiIGZpbGwtb3BhY2l0eT0iMSIgZmlsbC1ydWxlPSJldmVub2RkIi8+PC9nPjxnIGNsaXAtcGF0aD0idXJsKCMzNDVjMDFkMjRmKSI+PHBhdGggZmlsbD0iI2ZmZmZmZiIgZD0iTSAxMC44OTA2MjUgNy4yMDcwMzEgTCAxNS45MjE4NzUgNy4yMDcwMzEgTCAxNS45MjE4NzUgOS4yMTg3NSBMIDE3Ljk1NzAzMSA5LjIxODc1IEwgMTcuOTU3MDMxIDE3LjM4NjcxOSBMIDEwLjY3OTY4OCAxNy4zODY3MTkgTCAxMC42Nzk2ODggNy4yMDcwMzEgWiBNIDEyLjU1NDY4OCA5LjU1MDc4MSBDIDEyLjAyMzQzOCA5Ljg3NSAxMS42Nzk2ODggMTAuMzgyODEyIDExLjU0Njg3NSAxMC45Mzc1IEMgMTEuNDE0MDYyIDExLjQ5NjA5NCAxMS40OTYwOTQgMTIuMTAxNTYyIDExLjgyNDIxOSAxMi42MjUgQyAxMi4xNTIzNDQgMTMuMTUyMzQ0IDEyLjY2NDA2MiAxMy40OTYwOTQgMTMuMjI2NTYyIDEzLjYyNSBDIDEzLjYyODkwNiAxMy43MTg3NSAxNC4wNTQ2ODggMTMuNzAzMTI1IDE0LjQ1NzAzMSAxMy41NzAzMTIgTCAxNi4wOTM3NSAxNi4xODM1OTQgQyAxNi4xNjAxNTYgMTYuMjkyOTY5IDE2LjI1NzgxMiAxNi4zNzEwOTQgMTYuMzU5Mzc1IDE2LjQxNDA2MiBDIDE2LjQ4NDM3NSAxNi40NjQ4NDQgMTYuNjIxMDk0IDE2LjQ2NDg0NCAxNi43MzQzNzUgMTYuMzk0NTMxIEwgMTYuODgyODEyIDE2LjMwNDY4OCBDIDE2Ljk5NjA5NCAxNi4yMzQzNzUgMTcuMDU4NTk0IDE2LjExMzI4MSAxNy4wNjY0MDYgMTUuOTgwNDY5IEMgMTcuMDc0MjE5IDE1Ljg3MTA5NCAxNy4wNDI5NjkgMTUuNzUgMTYuOTc2NTYyIDE1LjY0MDYyNSBMIDE1LjMzOTg0NCAxMy4wMjczNDQgQyAxNS42NDA2MjUgMTIuNzI2NTYyIDE1Ljg0Mzc1IDEyLjM1NTQ2OSAxNS45Mzc1IDExLjk2MDkzOCBDIDE2LjA3MDMxMiAxMS40MDIzNDQgMTUuOTg4MjgxIDEwLjc5Njg3NSAxNS42NjAxNTYgMTAuMjczNDM4IEMgMTUuMzMyMDMxIDkuNzQ2MDk0IDE0LjgyMDMxMiA5LjQwMjM0NCAxNC4yNTc4MTIgOS4yNzM0MzggQyAxMy42OTUzMTIgOS4xNDQ1MzEgMTMuMDgyMDMxIDkuMjI2NTYyIDEyLjU1NDY4OCA5LjU1MDc4MSBaIE0gMTQuNDIxODc1IDEzLjEzMjgxMiBMIDE0LjQ2MDkzOCAxMy4xMTMyODEgQyAxNC40OTYwOTQgMTMuMTAxNTYyIDE0LjUyNzM0NCAxMy4wODU5MzggMTQuNTU0Njg4IDEzLjA3NDIxOSBMIDE0LjU1NDY4OCAxMy4wNzAzMTIgQyAxNC41NjY0MDYgMTMuMDY2NDA2IDE0LjU3NDIxOSAxMy4wNjI1IDE0LjU4NTkzOCAxMy4wNTQ2ODggQyAxNC42MjUgMTMuMDM1MTU2IDE0LjY2MDE1NiAxMy4wMTU2MjUgMTQuNjkxNDA2IDEyLjk5NjA5NCBDIDE0LjY5NTMxMiAxMi45OTYwOTQgMTQuNjk5MjE5IDEyLjk5MjE4OCAxNC43MDcwMzEgMTIuOTg4MjgxIEMgMTQuNzU3ODEyIDEyLjk1NzAzMSAxNC44MDg1OTQgMTIuOTIxODc1IDE0Ljg1NTQ2OSAxMi44ODY3MTkgQyAxNC44Nzg5MDYgMTIuODY3MTg4IDE0LjkwMjM0NCAxMi44NDc2NTYgMTQuOTI1NzgxIDEyLjgyODEyNSBMIDE0Ljk1MzEyNSAxMi44MDQ2ODggQyAxNS4yNDIxODggMTIuNTU0Njg4IDE1LjQzNzUgMTIuMjIyNjU2IDE1LjUyMzQzOCAxMS44NjMyODEgQyAxNS42Mjg5MDYgMTEuNDEwMTU2IDE1LjU2MjUgMTAuOTE3OTY5IDE1LjI5Njg3NSAxMC40OTYwOTQgQyAxNS4wMzEyNSAxMC4wNzAzMTIgMTQuNjE3MTg4IDkuNzkyOTY5IDE0LjE2MDE1NiA5LjY4NzUgQyAxMy43MDMxMjUgOS41ODIwMzEgMTMuMjA3MDMxIDkuNjQ0NTMxIDEyLjc3NzM0NCA5LjkxMDE1NiBDIDEyLjM1MTU2MiAxMC4xNzE4NzUgMTIuMDcwMzEyIDEwLjU4MjAzMSAxMS45NjA5MzggMTEuMDM1MTU2IEMgMTEuODU1NDY5IDExLjQ4ODI4MSAxMS45MjE4NzUgMTEuOTgwNDY5IDEyLjE4NzUgMTIuNDAyMzQ0IEMgMTIuNDUzMTI1IDEyLjgyODEyNSAxMi44NjcxODggMTMuMTA1NDY5IDEzLjMyNDIxOSAxMy4yMTA5MzggQyAxMy42ODM1OTQgMTMuMjk2ODc1IDE0LjA2NjQwNiAxMy4yNzM0MzggMTQuNDIxODc1IDEzLjEzMjgxMiAiIGZpbGwtb3BhY2l0eT0iMSIgZmlsbC1ydWxlPSJldmVub2RkIi8+PC9nPjxwYXRoIGZpbGw9IiMyMTIxMjEiIGQ9Ik0gMTYuNTA3ODEyIDE2LjAzNTE1NiBMIDE2LjUyMzQzOCAxNi4wMjM0MzggQyAxNi41MjM0MzggMTYuMDIzNDM4IDE2LjQ5NjA5NCAxNi4wNDI5NjkgMTYuNTA3ODEyIDE2LjAzNTE1NiAiIGZpbGwtb3BhY2l0eT0iMSIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZmlsbD0iIzIxMjEyMSIgZD0iTSAxNi42NTYyNSAxNS45NDUzMTIgQyAxNi42Njc5NjkgMTUuOTM3NSAxNi42NDA2MjUgMTUuOTUzMTI1IDE2LjY0MDYyNSAxNS45NTMxMjUgTCAxNi42NTYyNSAxNS45NDUzMTIgIiBmaWxsLW9wYWNpdHk9IjEiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMSI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjEuNTk0ODI5LCAxNS45NjAwNjIpIj48Zz48cGF0aCBkPSJNIDYuMzkwNjI1IC02LjUxNTYyNSBMIDMuNzY1NjI1IDAgTCAyLjU0Njg3NSAwIEwgLTAuMDc4MTI1IC02LjUxNTYyNSBMIDEgLTYuNTE1NjI1IEMgMS4xMjUgLTYuNTE1NjI1IDEuMjIyNjU2IC02LjQ4ODI4MSAxLjI5Njg3NSAtNi40Mzc1IEMgMS4zNjcxODggLTYuMzgyODEyIDEuNDIxODc1IC02LjMxMjUgMS40NTMxMjUgLTYuMjE4NzUgTCAyLjg1OTM3NSAtMi40Njg3NSBDIDIuOTIxODc1IC0yLjMyMDMxMiAyLjk3NjU2MiAtMi4xNjQwNjIgMy4wMzEyNSAtMiBDIDMuMDgyMDMxIC0xLjgzMjAzMSAzLjEyODkwNiAtMS42NjAxNTYgMy4xNzE4NzUgLTEuNDg0Mzc1IEMgMy4yMTA5MzggLTEuNjYwMTU2IDMuMjUzOTA2IC0xLjgzMjAzMSAzLjI5Njg3NSAtMiBDIDMuMzQ3NjU2IC0yLjE2NDA2MiAzLjM5ODQzOCAtMi4zMjAzMTIgMy40NTMxMjUgLTIuNDY4NzUgTCA0Ljg1OTM3NSAtNi4yMTg3NSBDIDQuODc4OTA2IC02LjI4OTA2MiA0LjkyNTc4MSAtNi4zNTkzNzUgNSAtNi40MjE4NzUgQyA1LjA4MjAzMSAtNi40ODQzNzUgNS4xNzk2ODggLTYuNTE1NjI1IDUuMjk2ODc1IC02LjUxNTYyNSBaIE0gNi4zOTA2MjUgLTYuNTE1NjI1ICIvPjwvZz48L2c+PC9nPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMSI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjcuOTAxNDYzLCAxNS45NjAwNjIpIj48Zz48cGF0aCBkPSJNIDEuNzgxMjUgLTQuNjI1IEwgMS43ODEyNSAwIEwgMC41NDY4NzUgMCBMIDAuNTQ2ODc1IC00LjYyNSBaIE0gMS45Mzc1IC01Ljk1MzEyNSBDIDEuOTM3NSAtNS44NDc2NTYgMS45MTQwNjIgLTUuNzUgMS44NzUgLTUuNjU2MjUgQyAxLjgzMjAzMSAtNS41NjI1IDEuNzczNDM4IC01LjQ3NjU2MiAxLjcwMzEyNSAtNS40MDYyNSBDIDEuNjI4OTA2IC01LjM0Mzc1IDEuNTQ2ODc1IC01LjI4OTA2MiAxLjQ1MzEyNSAtNS4yNSBDIDEuMzU5Mzc1IC01LjIxODc1IDEuMjU3ODEyIC01LjIwMzEyNSAxLjE1NjI1IC01LjIwMzEyNSBDIDEuMDUwNzgxIC01LjIwMzEyNSAwLjk1MzEyNSAtNS4yMTg3NSAwLjg1OTM3NSAtNS4yNSBDIDAuNzczNDM4IC01LjI4OTA2MiAwLjY5NTMxMiAtNS4zNDM3NSAwLjYyNSAtNS40MDYyNSBDIDAuNTUwNzgxIC01LjQ3NjU2MiAwLjQ5MjE4OCAtNS41NjI1IDAuNDUzMTI1IC01LjY1NjI1IEMgMC40MjE4NzUgLTUuNzUgMC40MDYyNSAtNS44NDc2NTYgMC40MDYyNSAtNS45NTMxMjUgQyAwLjQwNjI1IC02LjA1NDY4OCAwLjQyMTg3NSAtNi4xNDg0MzggMC40NTMxMjUgLTYuMjM0Mzc1IEMgMC40OTIxODggLTYuMzI4MTI1IDAuNTUwNzgxIC02LjQwNjI1IDAuNjI1IC02LjQ2ODc1IEMgMC42OTUzMTIgLTYuNTM5MDYyIDAuNzczNDM4IC02LjU5NzY1NiAwLjg1OTM3NSAtNi42NDA2MjUgQyAwLjk1MzEyNSAtNi42Nzk2ODggMS4wNTA3ODEgLTYuNzAzMTI1IDEuMTU2MjUgLTYuNzAzMTI1IEMgMS4yNTc4MTIgLTYuNzAzMTI1IDEuMzU5Mzc1IC02LjY3OTY4OCAxLjQ1MzEyNSAtNi42NDA2MjUgQyAxLjU0Njg3NSAtNi41OTc2NTYgMS42Mjg5MDYgLTYuNTM5MDYyIDEuNzAzMTI1IC02LjQ2ODc1IEMgMS43NzM0MzggLTYuNDA2MjUgMS44MzIwMzEgLTYuMzI4MTI1IDEuODc1IC02LjIzNDM3NSBDIDEuOTE0MDYyIC02LjE0ODQzOCAxLjkzNzUgLTYuMDU0Njg4IDEuOTM3NSAtNS45NTMxMjUgWiBNIDEuOTM3NSAtNS45NTMxMjUgIi8+PC9nPjwvZz48L2c+PGcgZmlsbD0iI2ZmZmZmZiIgZmlsbC1vcGFjaXR5PSIxIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzMC4yMzcyNTQsIDE1Ljk2MDA2MikiPjxnPjxwYXRoIGQ9Ik0gMy40NTMxMjUgLTIuODU5Mzc1IEMgMy40NTMxMjUgLTIuOTkyMTg4IDMuNDI5Njg4IC0zLjExNzE4OCAzLjM5MDYyNSAtMy4yMzQzNzUgQyAzLjM1OTM3NSAtMy4zNDc2NTYgMy4zMDQ2ODggLTMuNDQ1MzEyIDMuMjM0Mzc1IC0zLjUzMTI1IEMgMy4xNjAxNTYgLTMuNjI1IDMuMDY2NDA2IC0zLjY5NTMxMiAyLjk1MzEyNSAtMy43NSBDIDIuODM1OTM4IC0zLjgwMDc4MSAyLjcwMzEyNSAtMy44MjgxMjUgMi41NDY4NzUgLTMuODI4MTI1IEMgMi4yNDIxODggLTMuODI4MTI1IDIuMDA3ODEyIC0zLjc0MjE4OCAxLjg0Mzc1IC0zLjU3ODEyNSBDIDEuNjc1NzgxIC0zLjQxMDE1NiAxLjU2NjQwNiAtMy4xNzE4NzUgMS41MTU2MjUgLTIuODU5Mzc1IFogTSAxLjUgLTIuMTI1IEMgMS41MzkwNjIgLTEuNjg3NSAxLjY2NDA2MiAtMS4zNjcxODggMS44NzUgLTEuMTcxODc1IEMgMi4wODIwMzEgLTAuOTcyNjU2IDIuMzUxNTYyIC0wLjg3NSAyLjY4NzUgLTAuODc1IEMgMi44NTE1NjIgLTAuODc1IDMgLTAuODk0NTMxIDMuMTI1IC0wLjkzNzUgQyAzLjI1IC0wLjk3NjU2MiAzLjM1OTM3NSAtMS4wMTk1MzEgMy40NTMxMjUgLTEuMDYyNSBDIDMuNTQ2ODc1IC0xLjExMzI4MSAzLjYyODkwNiAtMS4xNjAxNTYgMy43MDMxMjUgLTEuMjAzMTI1IEMgMy43ODUxNTYgLTEuMjQyMTg4IDMuODYzMjgxIC0xLjI2NTYyNSAzLjkzNzUgLTEuMjY1NjI1IEMgNC4wMzEyNSAtMS4yNjU2MjUgNC4xMDkzNzUgLTEuMjI2NTYyIDQuMTcxODc1IC0xLjE1NjI1IEwgNC41MzEyNSAtMC43MDMxMjUgQyA0LjM5NDUzMSAtMC41NDY4NzUgNC4yNDIxODggLTAuNDE0MDYyIDQuMDc4MTI1IC0wLjMxMjUgQyAzLjkyMTg3NSAtMC4yMTg3NSAzLjc1NzgxMiAtMC4xNDA2MjUgMy41OTM3NSAtMC4wNzgxMjUgQyAzLjQyNTc4MSAtMC4wMjM0Mzc1IDMuMjUzOTA2IDAuMDA3ODEyNSAzLjA3ODEyNSAwLjAzMTI1IEMgMi44OTg0MzggMC4wNTA3ODEyIDIuNzM0Mzc1IDAuMDYyNSAyLjU3ODEyNSAwLjA2MjUgQyAyLjI1MzkwNiAwLjA2MjUgMS45NTMxMjUgMC4wMDc4MTI1IDEuNjcxODc1IC0wLjA5Mzc1IEMgMS4zOTA2MjUgLTAuMTk1MzEyIDEuMTQ0NTMxIC0wLjM1MTU2MiAwLjkzNzUgLTAuNTYyNSBDIDAuNzI2NTYyIC0wLjc2OTUzMSAwLjU2MjUgLTEuMDIzNDM4IDAuNDM3NSAtMS4zMjgxMjUgQyAwLjMyMDMxMiAtMS42NDA2MjUgMC4yNjU2MjUgLTIgMC4yNjU2MjUgLTIuNDA2MjUgQyAwLjI2NTYyNSAtMi43MjY1NjIgMC4zMTY0MDYgLTMuMDIzNDM4IDAuNDIxODc1IC0zLjI5Njg3NSBDIDAuNTIzNDM4IC0zLjU3ODEyNSAwLjY3MTg3NSAtMy44MjAzMTIgMC44NTkzNzUgLTQuMDMxMjUgQyAxLjA1NDY4OCAtNC4yMzgyODEgMS4yOTY4NzUgLTQuMzk4NDM4IDEuNTc4MTI1IC00LjUxNTYyNSBDIDEuODU5Mzc1IC00LjY0MDYyNSAyLjE3MTg3NSAtNC43MDMxMjUgMi41MTU2MjUgLTQuNzAzMTI1IEMgMi44MTY0MDYgLTQuNzAzMTI1IDMuMDkzNzUgLTQuNjU2MjUgMy4zNDM3NSAtNC41NjI1IEMgMy41OTM3NSAtNC40Njg3NSAzLjgwNDY4OCAtNC4zMjgxMjUgMy45ODQzNzUgLTQuMTQwNjI1IEMgNC4xNzE4NzUgLTMuOTYwOTM4IDQuMzEyNSAtMy43NDIxODggNC40MDYyNSAtMy40ODQzNzUgQyA0LjUwNzgxMiAtMy4yMjI2NTYgNC41NjI1IC0yLjkyNTc4MSA0LjU2MjUgLTIuNTkzNzUgQyA0LjU2MjUgLTIuNSA0LjU1NDY4OCAtMi40MjE4NzUgNC41NDY4NzUgLTIuMzU5Mzc1IEMgNC41MzUxNTYgLTIuMjk2ODc1IDQuNTE5NTMxIC0yLjI1IDQuNSAtMi4yMTg3NSBDIDQuNDc2NTYyIC0yLjE4NzUgNC40NDUzMTIgLTIuMTYwMTU2IDQuNDA2MjUgLTIuMTQwNjI1IEMgNC4zNzUgLTIuMTI4OTA2IDQuMzMyMDMxIC0yLjEyNSA0LjI4MTI1IC0yLjEyNSBaIE0gMS41IC0yLjEyNSAiLz48L2c+PC9nPjwvZz48ZyBmaWxsPSIjZmZmZmZmIiBmaWxsLW9wYWNpdHk9IjEiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDM1LjA1MjU3NiwgMTUuOTYwMDYyKSI+PGc+PHBhdGggZD0iTSA3LjIxODc1IC00LjYyNSBMIDUuNzY1NjI1IDAgTCA0Ljc2NTYyNSAwIEMgNC43MTA5MzggMCA0LjY2NDA2MiAtMC4wMTU2MjUgNC42MjUgLTAuMDQ2ODc1IEMgNC41ODIwMzEgLTAuMDc4MTI1IDQuNTUwNzgxIC0wLjEzMjgxMiA0LjUzMTI1IC0wLjIxODc1IEwgMy43ODEyNSAtMi43MTg3NSBDIDMuNzUgLTIuODEyNSAzLjcyMjY1NiAtMi45MDYyNSAzLjcwMzEyNSAtMyBDIDMuNjc5Njg4IC0zLjEwMTU2MiAzLjY2MDE1NiAtMy4yMDMxMjUgMy42NDA2MjUgLTMuMjk2ODc1IEMgMy42MTcxODggLTMuMjAzMTI1IDMuNTk3NjU2IC0zLjEwMTU2MiAzLjU3ODEyNSAtMyBDIDMuNTU0Njg4IC0yLjkwNjI1IDMuNTMxMjUgLTIuODEyNSAzLjUgLTIuNzE4NzUgTCAyLjczNDM3NSAtMC4yMTg3NSBDIDIuNjkxNDA2IC0wLjA3MDMxMjUgMi42MDE1NjIgMCAyLjQ2ODc1IDAgTCAxLjUxNTYyNSAwIEwgMC4wNDY4NzUgLTQuNjI1IEwgMS4wNDY4NzUgLTQuNjI1IEMgMS4xMjg5MDYgLTQuNjI1IDEuMjAzMTI1IC00LjYwMTU2MiAxLjI2NTYyNSAtNC41NjI1IEMgMS4zMjgxMjUgLTQuNTE5NTMxIDEuMzY3MTg4IC00LjQ2ODc1IDEuMzkwNjI1IC00LjQwNjI1IEwgMS45Njg3NSAtMi4xMDkzNzUgQyAyIC0xLjk2MDkzOCAyLjAyMzQzOCAtMS44MjAzMTIgMi4wNDY4NzUgLTEuNjg3NSBDIDIuMDc4MTI1IC0xLjU1MDc4MSAyLjEwOTM3NSAtMS40MTQwNjIgMi4xNDA2MjUgLTEuMjgxMjUgQyAyLjE3MTg3NSAtMS40MTQwNjIgMi4yMDcwMzEgLTEuNTUwNzgxIDIuMjUgLTEuNjg3NSBDIDIuMjg5MDYyIC0xLjgyMDMxMiAyLjMzMjAzMSAtMS45NjA5MzggMi4zNzUgLTIuMTA5Mzc1IEwgMy4wNjI1IC00LjQyMTg3NSBDIDMuMDgyMDMxIC00LjQ4NDM3NSAzLjExNzE4OCAtNC41MzUxNTYgMy4xNzE4NzUgLTQuNTc4MTI1IEMgMy4yMzQzNzUgLTQuNjE3MTg4IDMuMzA0Njg4IC00LjY0MDYyNSAzLjM5MDYyNSAtNC42NDA2MjUgTCAzLjkzNzUgLTQuNjQwNjI1IEMgNC4wMTk1MzEgLTQuNjQwNjI1IDQuMDkzNzUgLTQuNjE3MTg4IDQuMTU2MjUgLTQuNTc4MTI1IEMgNC4yMTg3NSAtNC41MzUxNTYgNC4yNTc4MTIgLTQuNDg0Mzc1IDQuMjgxMjUgLTQuNDIxODc1IEwgNC45Mzc1IC0yLjEwOTM3NSBDIDQuOTc2NTYyIC0xLjk3MjY1NiA1LjAxNTYyNSAtMS44MzIwMzEgNS4wNDY4NzUgLTEuNjg3NSBDIDUuMDg1OTM4IC0xLjU1MDc4MSA1LjEyODkwNiAtMS40MTAxNTYgNS4xNzE4NzUgLTEuMjY1NjI1IEMgNS4xOTE0MDYgLTEuNDEwMTU2IDUuMjEwOTM4IC0xLjU1MDc4MSA1LjIzNDM3NSAtMS42ODc1IEMgNS4yNjU2MjUgLTEuODIwMzEyIDUuMzAwNzgxIC0xLjk2MDkzOCA1LjM0Mzc1IC0yLjEwOTM3NSBMIDUuOTM3NSAtNC40MDYyNSBDIDUuOTU3MDMxIC00LjQ2ODc1IDYgLTQuNTE5NTMxIDYuMDYyNSAtNC41NjI1IEMgNi4xMjUgLTQuNjAxNTYyIDYuMTk1MzEyIC00LjYyNSA2LjI4MTI1IC00LjYyNSBaIE0gNy4yMTg3NSAtNC42MjUgIi8+PC9nPjwvZz48L2c+PGcgZmlsbD0iI2ZmZmZmZiIgZmlsbC1vcGFjaXR5PSIxIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSg0Mi4zMjQ5NjgsIDE1Ljk2MDA2MikiPjxnLz48L2c+PC9nPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMSI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDQuNDU4NjI0LCAxNS45NjAwNjIpIj48Zz48cGF0aCBkPSJNIDIuODkwNjI1IC0zLjI4MTI1IEMgMy4zMDQ2ODggLTMuMjgxMjUgMy42MTMyODEgLTMuMzc4OTA2IDMuODEyNSAtMy41NzgxMjUgQyA0LjAwNzgxMiAtMy43ODUxNTYgNC4xMDkzNzUgLTQuMDY2NDA2IDQuMTA5Mzc1IC00LjQyMTg3NSBDIDQuMTA5Mzc1IC00LjU3ODEyNSA0LjA4MjAzMSAtNC43MjI2NTYgNC4wMzEyNSAtNC44NTkzNzUgQyAzLjk3NjU2MiAtNC45OTIxODggMy44OTg0MzggLTUuMTA5Mzc1IDMuNzk2ODc1IC01LjIwMzEyNSBDIDMuNzAzMTI1IC01LjI5Njg3NSAzLjU3ODEyNSAtNS4zNjcxODggMy40MjE4NzUgLTUuNDIxODc1IEMgMy4yNzM0MzggLTUuNDcyNjU2IDMuMDk3NjU2IC01LjUgMi44OTA2MjUgLTUuNSBMIDIuMDMxMjUgLTUuNSBMIDIuMDMxMjUgLTMuMjgxMjUgWiBNIDIuODkwNjI1IC02LjUxNTYyNSBDIDMuMzI4MTI1IC02LjUxNTYyNSAzLjcwNzAzMSAtNi40NjA5MzggNC4wMzEyNSAtNi4zNTkzNzUgQyA0LjM2MzI4MSAtNi4yNTM5MDYgNC42MzI4MTIgLTYuMTA5Mzc1IDQuODQzNzUgLTUuOTIxODc1IEMgNS4wNTA3ODEgLTUuNzM0Mzc1IDUuMjAzMTI1IC01LjUwNzgxMiA1LjI5Njg3NSAtNS4yNSBDIDUuMzk4NDM4IC01IDUuNDUzMTI1IC00LjcyMjY1NiA1LjQ1MzEyNSAtNC40MjE4NzUgQyA1LjQ1MzEyNSAtNC4wOTc2NTYgNS4zOTg0MzggLTMuODAwNzgxIDUuMjk2ODc1IC0zLjUzMTI1IEMgNS4xOTE0MDYgLTMuMjY5NTMxIDUuMDMxMjUgLTMuMDM5MDYyIDQuODEyNSAtMi44NDM3NSBDIDQuNjAxNTYyIC0yLjY1NjI1IDQuMzM1OTM4IC0yLjUwMzkwNiA0LjAxNTYyNSAtMi4zOTA2MjUgQyAzLjY5MTQwNiAtMi4yODUxNTYgMy4zMTY0MDYgLTIuMjM0Mzc1IDIuODkwNjI1IC0yLjIzNDM3NSBMIDIuMDMxMjUgLTIuMjM0Mzc1IEwgMi4wMzEyNSAwIEwgMC42ODc1IDAgTCAwLjY4NzUgLTYuNTE1NjI1IFogTSAyLjg5MDYyNSAtNi41MTU2MjUgIi8+PC9nPjwvZz48L2c+PGcgZmlsbD0iI2ZmZmZmZiIgZmlsbC1vcGFjaXR5PSIxIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MC4wOTE0NzEsIDE1Ljk2MDA2MikiPjxnPjxwYXRoIGQ9Ik0gMS43NjU2MjUgLTYuNzAzMTI1IEwgMS43NjU2MjUgMCBMIDAuNTE1NjI1IDAgTCAwLjUxNTYyNSAtNi43MDMxMjUgWiBNIDEuNzY1NjI1IC02LjcwMzEyNSAiLz48L2c+PC9nPjwvZz48ZyBmaWxsPSIjZmZmZmZmIiBmaWxsLW9wYWNpdHk9IjEiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUyLjM3MzM1OSwgMTUuOTYwMDYyKSI+PGc+PHBhdGggZD0iTSAyLjkzNzUgLTEuOTM3NSBDIDIuNjMyODEyIC0xLjkxNDA2MiAyLjM3ODkwNiAtMS44ODI4MTIgMi4xNzE4NzUgLTEuODQzNzUgQyAxLjk3MjY1NiAtMS44MTI1IDEuODEyNSAtMS43NjU2MjUgMS42ODc1IC0xLjcwMzEyNSBDIDEuNTcwMzEyIC0xLjY0ODQzOCAxLjQ4ODI4MSAtMS41ODIwMzEgMS40Mzc1IC0xLjUgQyAxLjM5NDUzMSAtMS40MjU3ODEgMS4zNzUgLTEuMzQ3NjU2IDEuMzc1IC0xLjI2NTYyNSBDIDEuMzc1IC0xLjA3ODEyNSAxLjQyMTg3NSAtMC45NDUzMTIgMS41MTU2MjUgLTAuODc1IEMgMS42MTcxODggLTAuODAwNzgxIDEuNzU3ODEyIC0wLjc2NTYyNSAxLjkzNzUgLTAuNzY1NjI1IEMgMi4xNDQ1MzEgLTAuNzY1NjI1IDIuMzIwMzEyIC0wLjgwMDc4MSAyLjQ2ODc1IC0wLjg3NSBDIDIuNjI1IC0wLjk0NTMxMiAyLjc4MTI1IC0xLjA2MjUgMi45Mzc1IC0xLjIxODc1IFogTSAwLjQwNjI1IC0zLjk4NDM3NSBDIDAuNjc1NzgxIC00LjIzNDM3NSAwLjk3NjU2MiAtNC40MTQwNjIgMS4zMTI1IC00LjUzMTI1IEMgMS42NDQ1MzEgLTQuNjU2MjUgMiAtNC43MTg3NSAyLjM3NSAtNC43MTg3NSBDIDIuNjU2MjUgLTQuNzE4NzUgMi45MDYyNSAtNC42NzE4NzUgMy4xMjUgLTQuNTc4MTI1IEMgMy4zNDM3NSAtNC40OTIxODggMy41MjM0MzggLTQuMzY3MTg4IDMuNjcxODc1IC00LjIwMzEyNSBDIDMuODI4MTI1IC00LjA0Njg3NSAzLjk0MTQwNiAtMy44NTkzNzUgNC4wMTU2MjUgLTMuNjQwNjI1IEMgNC4wOTc2NTYgLTMuNDIxODc1IDQuMTQwNjI1IC0zLjE3NTc4MSA0LjE0MDYyNSAtMi45MDYyNSBMIDQuMTQwNjI1IDAgTCAzLjU3ODEyNSAwIEMgMy40NjA5MzggMCAzLjM3NSAtMC4wMTU2MjUgMy4zMTI1IC0wLjA0Njg3NSBDIDMuMjUgLTAuMDc4MTI1IDMuMTk1MzEyIC0wLjE0NDUzMSAzLjE1NjI1IC0wLjI1IEwgMy4wNjI1IC0wLjU0Njg3NSBDIDIuOTQ1MzEyIC0wLjQ1MzEyNSAyLjgzMjAzMSAtMC4zNjMyODEgMi43MTg3NSAtMC4yODEyNSBDIDIuNjEzMjgxIC0wLjIwNzAzMSAyLjUgLTAuMTQ0NTMxIDIuMzc1IC0wLjA5Mzc1IEMgMi4yNTc4MTIgLTAuMDM5MDYyNSAyLjEzMjgxMiAwIDIgMC4wMzEyNSBDIDEuODc1IDAuMDYyNSAxLjcyNjU2MiAwLjA3ODEyNSAxLjU2MjUgMC4wNzgxMjUgQyAxLjM1MTU2MiAwLjA3ODEyNSAxLjE2NDA2MiAwLjA1MDc4MTIgMSAwIEMgMC44MzIwMzEgLTAuMDYyNSAwLjY4NzUgLTAuMTQ0NTMxIDAuNTYyNSAtMC4yNSBDIDAuNDQ1MzEyIC0wLjM1MTU2MiAwLjM1MTU2MiAtMC40ODQzNzUgMC4yODEyNSAtMC42NDA2MjUgQyAwLjIxODc1IC0wLjgwNDY4OCAwLjE4NzUgLTAuOTg4MjgxIDAuMTg3NSAtMS4xODc1IEMgMC4xODc1IC0xLjM2MzI4MSAwLjIyNjU2MiAtMS41MzUxNTYgMC4zMTI1IC0xLjcwMzEyNSBDIDAuNDA2MjUgLTEuODc4OTA2IDAuNTU0Njg4IC0yLjAzNTE1NiAwLjc2NTYyNSAtMi4xNzE4NzUgQyAwLjk3MjY1NiAtMi4zMDQ2ODggMS4yNTM5MDYgLTIuNDIxODc1IDEuNjA5Mzc1IC0yLjUxNTYyNSBDIDEuOTYwOTM4IC0yLjYwOTM3NSAyLjQwNjI1IC0yLjY2MDE1NiAyLjkzNzUgLTIuNjcxODc1IEwgMi45Mzc1IC0yLjkwNjI1IEMgMi45Mzc1IC0zLjE5NTMxMiAyLjg3NSAtMy40MTAxNTYgMi43NSAtMy41NDY4NzUgQyAyLjYyNSAtMy42Nzk2ODggMi40NDUzMTIgLTMuNzUgMi4yMTg3NSAtMy43NSBDIDIuMDUwNzgxIC0zLjc1IDEuOTEwMTU2IC0zLjcyNjU2MiAxLjc5Njg3NSAtMy42ODc1IEMgMS42Nzk2ODggLTMuNjU2MjUgMS41NzgxMjUgLTMuNjEzMjgxIDEuNDg0Mzc1IC0zLjU2MjUgQyAxLjM5ODQzOCAtMy41MTk1MzEgMS4zMjAzMTIgLTMuNDc2NTYyIDEuMjUgLTMuNDM3NSBDIDEuMTc1NzgxIC0zLjM5NDUzMSAxLjA5Mzc1IC0zLjM3NSAxIC0zLjM3NSBDIDAuOTA2MjUgLTMuMzc1IDAuODI4MTI1IC0zLjM5NDUzMSAwLjc2NTYyNSAtMy40Mzc1IEMgMC43MTA5MzggLTMuNDc2NTYyIDAuNjY0MDYyIC0zLjUzMTI1IDAuNjI1IC0zLjU5Mzc1IFogTSAwLjQwNjI1IC0zLjk4NDM3NSAiLz48L2c+PC9nPjwvZz48ZyBmaWxsPSIjZmZmZmZmIiBmaWxsLW9wYWNpdHk9IjEiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU2Ljk3MzA2OSwgMTUuOTYwMDYyKSI+PGc+PHBhdGggZD0iTSA0LjgxMjUgLTQuNjI1IEwgMi4zMTI1IDEuMjUgQyAyLjI2OTUzMSAxLjMzMjAzMSAyLjIxODc1IDEuMzk0NTMxIDIuMTU2MjUgMS40Mzc1IEMgMi4xMDE1NjIgMS40NzY1NjIgMi4wMTk1MzEgMS41IDEuOTA2MjUgMS41IEwgMC45ODQzNzUgMS41IEwgMS44NTkzNzUgLTAuMzc1IEwgMCAtNC42MjUgTCAxLjA5Mzc1IC00LjYyNSBDIDEuMTg3NSAtNC42MjUgMS4yNTc4MTIgLTQuNjAxNTYyIDEuMzEyNSAtNC41NjI1IEMgMS4zNjMyODEgLTQuNTE5NTMxIDEuNDA2MjUgLTQuNDY4NzUgMS40Mzc1IC00LjQwNjI1IEwgMi4zMTI1IC0yLjE4NzUgQyAyLjM0Mzc1IC0yLjEwMTU2MiAyLjM2NzE4OCAtMi4wMTU2MjUgMi4zOTA2MjUgLTEuOTIxODc1IEMgMi40MjE4NzUgLTEuODM1OTM4IDIuNDQ1MzEyIC0xLjc1MzkwNiAyLjQ2ODc1IC0xLjY3MTg3NSBDIDIuNTMxMjUgLTEuODQ3NjU2IDIuNTkzNzUgLTIuMDIzNDM4IDIuNjU2MjUgLTIuMjAzMTI1IEwgMy40ODQzNzUgLTQuNDA2MjUgQyAzLjUwMzkwNiAtNC40Njg3NSAzLjU0Njg3NSAtNC41MTk1MzEgMy42MDkzNzUgLTQuNTYyNSBDIDMuNjcxODc1IC00LjYwMTU2MiAzLjczODI4MSAtNC42MjUgMy44MTI1IC00LjYyNSBaIE0gNC44MTI1IC00LjYyNSAiLz48L2c+PC9nPjwvZz48ZyBmaWxsPSIjZmZmZmZmIiBmaWxsLW9wYWNpdHk9IjEiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDYxLjc1MjQ1MywgMTUuOTYwMDYyKSI+PGc+PHBhdGggZD0iTSAxLjc1IC0xLjIxODc1IEMgMS44NjMyODEgLTEuMDgyMDMxIDEuOTg4MjgxIC0wLjk4ODI4MSAyLjEyNSAtMC45Mzc1IEMgMi4yNjk1MzEgLTAuODgyODEyIDIuNDE0MDYyIC0wLjg1OTM3NSAyLjU2MjUgLTAuODU5Mzc1IEMgMi43MDcwMzEgLTAuODU5Mzc1IDIuODQzNzUgLTAuODgyODEyIDIuOTY4NzUgLTAuOTM3NSBDIDMuMDkzNzUgLTEgMy4xOTUzMTIgLTEuMDg1OTM4IDMuMjgxMjUgLTEuMjAzMTI1IEMgMy4zNzUgLTEuMzI4MTI1IDMuNDQ1MzEyIC0xLjQ4NDM3NSAzLjUgLTEuNjcxODc1IEMgMy41NTA3ODEgLTEuODY3MTg4IDMuNTc4MTI1IC0yLjEwOTM3NSAzLjU3ODEyNSAtMi4zOTA2MjUgQyAzLjU3ODEyNSAtMi42Mjg5MDYgMy41NTQ2ODggLTIuODMyMDMxIDMuNTE1NjI1IC0zIEMgMy40NzI2NTYgLTMuMTc1NzgxIDMuNDEwMTU2IC0zLjMyMDMxMiAzLjMyODEyNSAtMy40Mzc1IEMgMy4yNTM5MDYgLTMuNTUwNzgxIDMuMTYwMTU2IC0zLjYyODkwNiAzLjA0Njg3NSAtMy42NzE4NzUgQyAyLjk0MTQwNiAtMy43MjI2NTYgMi44MTY0MDYgLTMuNzUgMi42NzE4NzUgLTMuNzUgQyAyLjQ3MjY1NiAtMy43NSAyLjMwMDc4MSAtMy43MDcwMzEgMi4xNTYyNSAtMy42MjUgQyAyLjAxOTUzMSAtMy41MzkwNjIgMS44ODI4MTIgLTMuNDE0MDYyIDEuNzUgLTMuMjUgWiBNIDEuNzUgLTQuMDkzNzUgQyAxLjkzNzUgLTQuMjgxMjUgMi4xNDA2MjUgLTQuNDI1NzgxIDIuMzU5Mzc1IC00LjUzMTI1IEMgMi41NzgxMjUgLTQuNjQ0NTMxIDIuODI4MTI1IC00LjcwMzEyNSAzLjEwOTM3NSAtNC43MDMxMjUgQyAzLjM2NzE4OCAtNC43MDMxMjUgMy42MDE1NjIgLTQuNjQ4NDM4IDMuODEyNSAtNC41NDY4NzUgQyA0LjAzMTI1IC00LjQ0MTQwNiA0LjIxMDkzOCAtNC4yODkwNjIgNC4zNTkzNzUgLTQuMDkzNzUgQyA0LjUxNTYyNSAtMy44OTQ1MzEgNC42MzI4MTIgLTMuNjU2MjUgNC43MTg3NSAtMy4zNzUgQyA0LjgwMDc4MSAtMy4wOTM3NSA0Ljg0Mzc1IC0yLjc4MTI1IDQuODQzNzUgLTIuNDM3NSBDIDQuODQzNzUgLTIuMDYyNSA0Ljc5Njg3NSAtMS43MTg3NSA0LjcwMzEyNSAtMS40MDYyNSBDIDQuNjA5Mzc1IC0xLjEwMTU2MiA0LjQ3MjY1NiAtMC44NDM3NSA0LjI5Njg3NSAtMC42MjUgQyA0LjEyODkwNiAtMC40MDYyNSAzLjkyMTg3NSAtMC4yMzQzNzUgMy42NzE4NzUgLTAuMTA5Mzc1IEMgMy40Mjk2ODggMC4wMDM5MDYyNSAzLjE2NDA2MiAwLjA2MjUgMi44NzUgMC4wNjI1IEMgMi43MjY1NjIgMC4wNjI1IDIuNTk3NjU2IDAuMDQ2ODc1IDIuNDg0Mzc1IDAuMDE1NjI1IEMgMi4zNjcxODggLTAuMDAzOTA2MjUgMi4yNjU2MjUgLTAuMDM5MDYyNSAyLjE3MTg3NSAtMC4wOTM3NSBDIDIuMDc4MTI1IC0wLjE0NDUzMSAxLjk4ODI4MSAtMC4yMDMxMjUgMS45MDYyNSAtMC4yNjU2MjUgQyAxLjgyMDMxMiAtMC4zMzU5MzggMS43NSAtMC40MjE4NzUgMS42ODc1IC0wLjUxNTYyNSBMIDEuNjI1IC0wLjIzNDM3NSBDIDEuNjAxNTYyIC0wLjE0ODQzOCAxLjU2NjQwNiAtMC4wODU5Mzc1IDEuNTE1NjI1IC0wLjA0Njg3NSBDIDEuNDcyNjU2IC0wLjAxNTYyNSAxLjQxMDE1NiAwIDEuMzI4MTI1IDAgTCAwLjUxNTYyNSAwIEwgMC41MTU2MjUgLTYuNzAzMTI1IEwgMS43NSAtNi43MDMxMjUgWiBNIDEuNzUgLTQuMDkzNzUgIi8+PC9nPjwvZz48L2c+PGcgZmlsbD0iI2ZmZmZmZiIgZmlsbC1vcGFjaXR5PSIxIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSg2Ni44ODIyMDYsIDE1Ljk2MDA2MikiPjxnPjxwYXRoIGQ9Ik0gMi41OTM3NSAtNC43MDMxMjUgQyAyLjk0NTMxMiAtNC43MDMxMjUgMy4yNjU2MjUgLTQuNjQ0NTMxIDMuNTQ2ODc1IC00LjUzMTI1IEMgMy44MjgxMjUgLTQuNDI1NzgxIDQuMDcwMzEyIC00LjI2OTUzMSA0LjI4MTI1IC00LjA2MjUgQyA0LjQ4ODI4MSAtMy44NTE1NjIgNC42NDQ1MzEgLTMuNjAxNTYyIDQuNzUgLTMuMzEyNSBDIDQuODYzMjgxIC0zLjAxOTUzMSA0LjkyMTg3NSAtMi42OTE0MDYgNC45MjE4NzUgLTIuMzI4MTI1IEMgNC45MjE4NzUgLTEuOTUzMTI1IDQuODYzMjgxIC0xLjYxNzE4OCA0Ljc1IC0xLjMyODEyNSBDIDQuNjQ0NTMxIC0xLjAzNTE1NiA0LjQ4ODI4MSAtMC43ODUxNTYgNC4yODEyNSAtMC41NzgxMjUgQyA0LjA3MDMxMiAtMC4zNjcxODggMy44MjgxMjUgLTAuMjA3MDMxIDMuNTQ2ODc1IC0wLjA5Mzc1IEMgMy4yNjU2MjUgMC4wMDc4MTI1IDIuOTQ1MzEyIDAuMDYyNSAyLjU5Mzc1IDAuMDYyNSBDIDIuMjUgMC4wNjI1IDEuOTI5Njg4IDAuMDA3ODEyNSAxLjY0MDYyNSAtMC4wOTM3NSBDIDEuMzU5Mzc1IC0wLjIwNzAzMSAxLjExMzI4MSAtMC4zNjcxODggMC45MDYyNSAtMC41NzgxMjUgQyAwLjcwNzAzMSAtMC43ODUxNTYgMC41NTA3ODEgLTEuMDM1MTU2IDAuNDM3NSAtMS4zMjgxMjUgQyAwLjMyMDMxMiAtMS42MTcxODggMC4yNjU2MjUgLTEuOTUzMTI1IDAuMjY1NjI1IC0yLjMyODEyNSBDIDAuMjY1NjI1IC0yLjY5MTQwNiAwLjMyMDMxMiAtMy4wMTk1MzEgMC40Mzc1IC0zLjMxMjUgQyAwLjU1MDc4MSAtMy42MDE1NjIgMC43MDcwMzEgLTMuODUxNTYyIDAuOTA2MjUgLTQuMDYyNSBDIDEuMTEzMjgxIC00LjI2OTUzMSAxLjM1OTM3NSAtNC40MjU3ODEgMS42NDA2MjUgLTQuNTMxMjUgQyAxLjkyOTY4OCAtNC42NDQ1MzEgMi4yNSAtNC43MDMxMjUgMi41OTM3NSAtNC43MDMxMjUgWiBNIDIuNTkzNzUgLTAuODU5Mzc1IEMgMi45NDUzMTIgLTAuODU5Mzc1IDMuMjA3MDMxIC0wLjk3NjU2MiAzLjM3NSAtMS4yMTg3NSBDIDMuNTUwNzgxIC0xLjQ2ODc1IDMuNjQwNjI1IC0xLjgzMjAzMSAzLjY0MDYyNSAtMi4zMTI1IEMgMy42NDA2MjUgLTIuNzg5MDYyIDMuNTUwNzgxIC0zLjE0ODQzOCAzLjM3NSAtMy4zOTA2MjUgQyAzLjIwNzAzMSAtMy42NDA2MjUgMi45NDUzMTIgLTMuNzY1NjI1IDIuNTkzNzUgLTMuNzY1NjI1IEMgMi4yMzgyODEgLTMuNzY1NjI1IDEuOTcyNjU2IC0zLjY0MDYyNSAxLjc5Njg3NSAtMy4zOTA2MjUgQyAxLjYyODkwNiAtMy4xNDg0MzggMS41NDY4NzUgLTIuNzg5MDYyIDEuNTQ2ODc1IC0yLjMxMjUgQyAxLjU0Njg3NSAtMS44MzIwMzEgMS42Mjg5MDYgLTEuNDY4NzUgMS43OTY4NzUgLTEuMjE4NzUgQyAxLjk3MjY1NiAtMC45NzY1NjIgMi4yMzgyODEgLTAuODU5Mzc1IDIuNTkzNzUgLTAuODU5Mzc1IFogTSAyLjU5Mzc1IC0wLjg1OTM3NSAiLz48L2c+PC9nPjwvZz48ZyBmaWxsPSIjZmZmZmZmIiBmaWxsLW9wYWNpdHk9IjEiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcyLjA3MDM1NiwgMTUuOTYwMDYyKSI+PGc+PHBhdGggZD0iTSAyLjU5Mzc1IC00LjcwMzEyNSBDIDIuOTQ1MzEyIC00LjcwMzEyNSAzLjI2NTYyNSAtNC42NDQ1MzEgMy41NDY4NzUgLTQuNTMxMjUgQyAzLjgyODEyNSAtNC40MjU3ODEgNC4wNzAzMTIgLTQuMjY5NTMxIDQuMjgxMjUgLTQuMDYyNSBDIDQuNDg4MjgxIC0zLjg1MTU2MiA0LjY0NDUzMSAtMy42MDE1NjIgNC43NSAtMy4zMTI1IEMgNC44NjMyODEgLTMuMDE5NTMxIDQuOTIxODc1IC0yLjY5MTQwNiA0LjkyMTg3NSAtMi4zMjgxMjUgQyA0LjkyMTg3NSAtMS45NTMxMjUgNC44NjMyODEgLTEuNjE3MTg4IDQuNzUgLTEuMzI4MTI1IEMgNC42NDQ1MzEgLTEuMDM1MTU2IDQuNDg4MjgxIC0wLjc4NTE1NiA0LjI4MTI1IC0wLjU3ODEyNSBDIDQuMDcwMzEyIC0wLjM2NzE4OCAzLjgyODEyNSAtMC4yMDcwMzEgMy41NDY4NzUgLTAuMDkzNzUgQyAzLjI2NTYyNSAwLjAwNzgxMjUgMi45NDUzMTIgMC4wNjI1IDIuNTkzNzUgMC4wNjI1IEMgMi4yNSAwLjA2MjUgMS45Mjk2ODggMC4wMDc4MTI1IDEuNjQwNjI1IC0wLjA5Mzc1IEMgMS4zNTkzNzUgLTAuMjA3MDMxIDEuMTEzMjgxIC0wLjM2NzE4OCAwLjkwNjI1IC0wLjU3ODEyNSBDIDAuNzA3MDMxIC0wLjc4NTE1NiAwLjU1MDc4MSAtMS4wMzUxNTYgMC40Mzc1IC0xLjMyODEyNSBDIDAuMzIwMzEyIC0xLjYxNzE4OCAwLjI2NTYyNSAtMS45NTMxMjUgMC4yNjU2MjUgLTIuMzI4MTI1IEMgMC4yNjU2MjUgLTIuNjkxNDA2IDAuMzIwMzEyIC0zLjAxOTUzMSAwLjQzNzUgLTMuMzEyNSBDIDAuNTUwNzgxIC0zLjYwMTU2MiAwLjcwNzAzMSAtMy44NTE1NjIgMC45MDYyNSAtNC4wNjI1IEMgMS4xMTMyODEgLTQuMjY5NTMxIDEuMzU5Mzc1IC00LjQyNTc4MSAxLjY0MDYyNSAtNC41MzEyNSBDIDEuOTI5Njg4IC00LjY0NDUzMSAyLjI1IC00LjcwMzEyNSAyLjU5Mzc1IC00LjcwMzEyNSBaIE0gMi41OTM3NSAtMC44NTkzNzUgQyAyLjk0NTMxMiAtMC44NTkzNzUgMy4yMDcwMzEgLTAuOTc2NTYyIDMuMzc1IC0xLjIxODc1IEMgMy41NTA3ODEgLTEuNDY4NzUgMy42NDA2MjUgLTEuODMyMDMxIDMuNjQwNjI1IC0yLjMxMjUgQyAzLjY0MDYyNSAtMi43ODkwNjIgMy41NTA3ODEgLTMuMTQ4NDM4IDMuMzc1IC0zLjM5MDYyNSBDIDMuMjA3MDMxIC0zLjY0MDYyNSAyLjk0NTMxMiAtMy43NjU2MjUgMi41OTM3NSAtMy43NjU2MjUgQyAyLjIzODI4MSAtMy43NjU2MjUgMS45NzI2NTYgLTMuNjQwNjI1IDEuNzk2ODc1IC0zLjM5MDYyNSBDIDEuNjI4OTA2IC0zLjE0ODQzOCAxLjU0Njg3NSAtMi43ODkwNjIgMS41NDY4NzUgLTIuMzEyNSBDIDEuNTQ2ODc1IC0xLjgzMjAzMSAxLjYyODkwNiAtMS40Njg3NSAxLjc5Njg3NSAtMS4yMTg3NSBDIDEuOTcyNjU2IC0wLjk3NjU2MiAyLjIzODI4MSAtMC44NTkzNzUgMi41OTM3NSAtMC44NTkzNzUgWiBNIDIuNTkzNzUgLTAuODU5Mzc1ICIvPjwvZz48L2c+PC9nPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMSI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNzcuMjU4NTA2LCAxNS45NjAwNjIpIj48Zz48cGF0aCBkPSJNIDEuNzUgLTYuNzAzMTI1IEwgMS43NSAtMi44OTA2MjUgTCAxLjk1MzEyNSAtMi44OTA2MjUgQyAyLjAzNTE1NiAtMi44OTA2MjUgMi4wOTc2NTYgLTIuODk4NDM4IDIuMTQwNjI1IC0yLjkyMTg3NSBDIDIuMTc5Njg4IC0yLjk1MzEyNSAyLjIyNjU2MiAtMyAyLjI4MTI1IC0zLjA2MjUgTCAzLjI5Njg3NSAtNC40MjE4NzUgQyAzLjM0NzY1NiAtNC40OTIxODggMy40MDYyNSAtNC41NDY4NzUgMy40Njg3NSAtNC41NzgxMjUgQyAzLjUzOTA2MiAtNC42MDkzNzUgMy42MjUgLTQuNjI1IDMuNzE4NzUgLTQuNjI1IEwgNC44NTkzNzUgLTQuNjI1IEwgMy41MTU2MjUgLTIuOTM3NSBDIDMuNDEwMTU2IC0yLjgwMDc4MSAzLjI4OTA2MiAtMi42OTE0MDYgMy4xNTYyNSAtMi42MDkzNzUgQyAzLjIyNjU2MiAtMi41NTQ2ODggMy4yODkwNjIgLTIuNSAzLjM0Mzc1IC0yLjQzNzUgQyAzLjM5NDUzMSAtMi4zNzUgMy40NDE0MDYgLTIuMzA0Njg4IDMuNDg0Mzc1IC0yLjIzNDM3NSBMIDQuOTIxODc1IDAgTCAzLjgxMjUgMCBDIDMuNzA3MDMxIDAgMy42MTcxODggLTAuMDE1NjI1IDMuNTQ2ODc1IC0wLjA0Njg3NSBDIDMuNDg0Mzc1IC0wLjA3ODEyNSAzLjQyOTY4OCAtMC4xMzI4MTIgMy4zOTA2MjUgLTAuMjE4NzUgTCAyLjM0Mzc1IC0xLjkyMTg3NSBDIDIuMzAwNzgxIC0xLjk5MjE4OCAyLjI1MzkwNiAtMi4wMzkwNjIgMi4yMDMxMjUgLTIuMDYyNSBDIDIuMTYwMTU2IC0yLjA4MjAzMSAyLjA5NzY1NiAtMi4wOTM3NSAyLjAxNTYyNSAtMi4wOTM3NSBMIDEuNzUgLTIuMDkzNzUgTCAxLjc1IDAgTCAwLjUxNTYyNSAwIEwgMC41MTU2MjUgLTYuNzAzMTI1IFogTSAxLjc1IC02LjcwMzEyNSAiLz48L2c+PC9nPjwvZz48L3N2Zz4=');" onclick="https://drive.google.com/file/d/15GcTRJdVwiKkb9HIFF7VnzSsqG9itQNc/view?usp=sharing"></div></td>
        <td style="padding: 10px 20px;"><div style="background-color: lightblue; display: inline-block; border-radius: 4px; cursor: pointer; height: 32px; border: none; width: 123px; background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI4IiBoZWlnaHQ9IjMyIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMjgiIGhlaWdodD0iMzIiIHJ4PSI0IiBmaWxsPSIjRkY2QzM3Ii8+PHBhdGggZD0iTTEyIDEwLjg4M2EuNS41IDAgMCAxIC43NTctLjQyOWw4LjUyOCA1LjExN2EuNS41IDAgMCAxIDAgLjg1OGwtOC41MjggNS4xMTdhLjUuNSAwIDAgMS0uNzU3LS40M1YxMC44ODRaTTI3Ljg4OSAyMC41MDloMS41OHYtMy4xOTdoMS42MTFsMS43MTMgMy4xOTdoMS43NjRsLTEuODg3LTMuNDZjMS4wMjctLjQxNCAxLjU2OC0xLjI5MiAxLjU2OC0yLjQ3NyAwLTEuNjY2LTEuMDc0LTIuNzktMy4wNzctMi43OWgtMy4yNzN2OC43MjdaTTI5LjQ2OCAxNnYtMi44OThoMS40NWMxLjE4IDAgMS43MDguNTQxIDEuNzA4IDEuNDcgMCAuOTMtLjUyOCAxLjQyOC0xLjcgMS40MjhIMjkuNDdaTTM5Ljc5NyAxNy43NTZjMCAuOTk3LS43MTIgMS40OTEtMS4zOTQgMS40OTEtLjc0MSAwLTEuMjM1LS41MjQtMS4yMzUtMS4zNTV2LTMuOTI5aC0xLjU0M3Y0LjE2OGMwIDEuNTcyLjg5NSAyLjQ2MyAyLjE4MiAyLjQ2My45OCAwIDEuNjctLjUxNiAxLjk2OS0xLjI0OWguMDY4djEuMTY0aDEuNDk1di02LjU0NmgtMS41NDJ2My43OTNaTTQ0LjQ2OCAxNi42NzNjMC0uOTQ2LjU3MS0xLjQ5MSAxLjM4NS0xLjQ5MS43OTcgMCAxLjI3NC41MjQgMS4yNzQgMS4zOTd2My45M2gxLjU0M1YxNi4zNGMuMDA0LTEuNTY4LS44OS0yLjQ2My0yLjI0MS0yLjQ2My0uOTggMC0xLjY1NC40NjktMS45NTIgMS4xOTdINDQuNHYtMS4xMTJoLTEuNDc0djYuNTQ2aDEuNTQydi0zLjgzNlpNNTMuMjE1IDIwLjUwOWgxLjU0MnYtNi41NDZoLTEuNTQydjYuNTQ2Wm0uNzc1LTcuNDc1Yy40OSAwIC44OTEtLjM3NS44OTEtLjgzNSAwLS40NjUtLjQtLjg0LS44OS0uODQtLjQ5NSAwLS44OTUuMzc1LS44OTUuODQgMCAuNDYuNC44MzUuODk0LjgzNVpNNTcuODg2IDE2LjY3M2MwLS45NDYuNTcxLTEuNDkxIDEuMzg1LTEuNDkxLjc5NyAwIDEuMjc0LjUyNCAxLjI3NCAxLjM5N3YzLjkzaDEuNTQzVjE2LjM0Yy4wMDQtMS41NjgtLjg5LTIuNDYzLTIuMjQxLTIuNDYzLS45OCAwLTEuNjU0LjQ2OS0xLjk1MiAxLjE5N2gtLjA3N3YtMS4xMTJoLTEuNDc0djYuNTQ2aDEuNTQydi0zLjgzNlpNNjYuNzAxIDIwLjUwOWgxLjU4MXYtMi45NWgxLjY3YzIuMDE2IDAgMy4wOTgtMS4yMSAzLjA5OC0yLjg4OSAwLTEuNjY2LTEuMDctMi44ODktMy4wNzYtMi44ODlINjYuN3Y4LjcyOFptMS41ODEtNC4yNXYtMy4xNTdoMS40NDljMS4xODQgMCAxLjcwOS42NCAxLjcwOSAxLjU2OSAwIC45MjgtLjUyNSAxLjU4OS0xLjcgMS41ODloLTEuNDU4Wk03Ny4xMTcgMjAuNjM2YzEuOTE3IDAgMy4xMzYtMS4zNSAzLjEzNi0zLjM3NSAwLTIuMDI4LTEuMjE5LTMuMzgzLTMuMTM2LTMuMzgzLTEuOTE4IDAtMy4xMzYgMS4zNTUtMy4xMzYgMy4zODMgMCAyLjAyNCAxLjIxOCAzLjM3NSAzLjEzNiAzLjM3NVptLjAwOC0xLjIzNWMtMS4wNiAwLTEuNTgtLjk0Ny0xLjU4LTIuMTQ0cy41Mi0yLjE1NiAxLjU4LTIuMTU2YzEuMDQ0IDAgMS41NjQuOTU5IDEuNTY0IDIuMTU2cy0uNTIgMi4xNDQtMS41NjQgMi4xNDRaTTg2LjczNiAxNS42OTNjLS4yMTMtMS4xMDgtMS4xLTEuODE1LTIuNjM0LTEuODE1LTEuNTc2IDAtMi42NS43NzUtMi42NDYgMS45ODYtLjAwNC45NTQuNTg0IDEuNTg1IDEuODQgMS44NDVsMS4xMTcuMjM0Yy42MDEuMTMyLjg4My4zNzUuODgzLjc0NiAwIC40NDctLjQ4Ni43ODQtMS4yMi43ODQtLjcwNyAwLTEuMTY3LS4zMDctMS4yOTktLjg5NWwtMS41MDQuMTQ1Yy4xOTIgMS4yMDIgMS4yMDEgMS45MTMgMi44MDggMS45MTMgMS42MzYgMCAyLjc5MS0uODQ4IDIuNzk1LTIuMDg4LS4wMDQtLjkzMy0uNjA1LTEuNTA0LTEuODQtMS43NzJsLTEuMTE3LS4yNGMtLjY2NS0uMTQ4LS45MjktLjM3OC0uOTI1LS43NTgtLjAwNC0uNDQzLjQ4Ni0uNzUgMS4xMy0uNzUuNzExIDAgMS4wODYuMzg4IDEuMjA2LjgxOWwxLjQwNi0uMTU0Wk05MS40MTcgMTMuOTYzaC0xLjI5MXYtMS41NjhoLTEuNTQzdjEuNTY4aC0uOTI5djEuMTkzaC45M3YzLjY0Yy0uMDEgMS4yMzEuODg1IDEuODM2IDIuMDQ0IDEuODAyYTMuMSAzLjEgMCAwIDAgLjkwOC0uMTUzbC0uMjYtMS4yMDZjLS4wODUuMDItLjI2LjA2LS40NTEuMDYtLjM4OCAwLS43LS4xMzctLjctLjc2di0zLjM4M2gxLjI5MnYtMS4xOTNaTTkyLjcwNyAyMC41MDloMS41NDN2LTMuOThjMC0uODA2LjUzNy0xLjM1MSAxLjIwMS0xLjM1MS42NTIgMCAxLjEuNDM4IDEuMSAxLjExMnY0LjIxOWgxLjUxM3YtNC4wODNjMC0uNzM3LjQzOS0xLjI0OCAxLjE4NC0xLjI0OC42MjIgMCAxLjExNy4zNjYgMS4xMTcgMS4xNzZ2NC4xNTVoMS41NDd2LTQuMzk0YzAtMS40NjItLjg0NC0yLjIzNy0yLjA0Ni0yLjIzNy0uOTUgMC0xLjY3NS40NjktMS45NjQgMS4xOTdoLS4wNjljLS4yNTEtLjc0MS0uODg2LTEuMTk3LTEuNzY4LTEuMTk3LS44NzggMC0xLjUzNC40NTEtMS44MDcgMS4xOTdoLS4wNzZ2LTEuMTEyaC0xLjQ3NXY2LjU0NlpNMTA1LjM2IDIwLjY0YzEuMDI3IDAgMS42NDEtLjQ4IDEuOTIyLTEuMDNoLjA1MXYuODk5aDEuNDgzdi00LjM4MWMwLTEuNzMtMS40MS0yLjI1LTIuNjU5LTIuMjUtMS4zNzYgMC0yLjQzMy42MTQtMi43NzQgMS44MDdsMS40NC4yMDRjLjE1NC0uNDQ3LjU4OC0uODMgMS4zNDItLjgzLjcxNiAwIDEuMTA4LjM2NiAxLjEwOCAxLjAxdi4wMjVjMCAuNDQzLS40NjQuNDY0LTEuNjE5LjU4OC0xLjI3LjEzNi0yLjQ4NC41MTUtMi40ODQgMS45OSAwIDEuMjg3Ljk0MiAxLjk2OSAyLjE5IDEuOTY5Wm0uNDAxLTEuMTMzYy0uNjQ0IDAtMS4xMDQtLjI5NC0xLjEwNC0uODYgMC0uNTkzLjUxNi0uODQgMS4yMDYtLjkzOC40MDUtLjA1NiAxLjIxNC0uMTU4IDEuNDE1LS4zMnYuNzcxYzAgLjczLS41ODggMS4zNDctMS41MTcgMS4zNDdaTTExMS45MSAxNi42NzNjMC0uOTQ2LjU3MS0xLjQ5MSAxLjM4NS0xLjQ5MS43OTcgMCAxLjI3NC41MjQgMS4yNzQgMS4zOTd2My45M2gxLjU0M1YxNi4zNGMuMDA0LTEuNTY4LS44OTEtMi40NjMtMi4yNDItMi40NjMtLjk4IDAtMS42NTMuNDY5LTEuOTUyIDEuMTk3aC0uMDc2di0xLjExMmgtMS40NzV2Ni41NDZoMS41NDN2LTMuODM2WiIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==');" onclick="window.open('https://www.postman.com/satusehat/workspace/satusehat-public/overview', '_blank');"></div></td>
    </tr>
</table>
