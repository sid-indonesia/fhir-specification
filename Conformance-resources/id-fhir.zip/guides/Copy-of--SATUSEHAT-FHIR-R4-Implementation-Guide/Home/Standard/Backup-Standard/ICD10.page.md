## {{page-title}}

ICD-10 adalah Klasifikasi Statistik Internasional Tentang Penyakit dan Masalah Kesehatan Revisi ke 10 atau the 10th revision of the International Statistical Classification of Diseases and Related Health Problems (ICD). ICD-10 adalah daftar klasifikasi medis yang dikeluarkan oleh WHO.

Akses terhadap ICD-10 dapat dilakukan melalui website pihak ketiga [website ICD-10](https://www.icd10data.com/ICD10CM/Codes).