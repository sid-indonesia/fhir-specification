
|<< {{pagelink:Home/Overview.page.md,text:Pengantar}} | {{pagelink:Home,text:Halaman Utama}} | {{pagelink:Home/Terminology/Terminology.page.md,text:Standar Terminologi}} >> |
| --- |------------------------- | --------------- |



|<< {{pagelink:Home/Terminology/InteroperabilityStandard.page.md,text:Standar Interoperabilitas}} | {{pagelink:Home,text:Halaman Utama}} | {{pagelink:Home/Terminology/FHIRIntroduction.page.md,text:Introduksi FHIR}} >> |
| --- |------------------------- | --------------- |


|<< {{pagelink:Home/Terminology/Terminology.page.md,text: Standar Terminologi}} | {{pagelink:Home,text:Halaman Utama}} | {{pagelink:Home/Developer/Onboarding.page.md,text:Tahapan Integrasi}} >> |
| --- |------------------------- | --------------- |