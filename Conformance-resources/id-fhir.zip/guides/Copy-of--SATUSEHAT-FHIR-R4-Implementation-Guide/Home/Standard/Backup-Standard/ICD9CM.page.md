## {{page-title}}

ICD-9-CM adalah Klasifikasi dan Kodefikasi Prosedur Internasional Revisi ke 9 Modifikasi Klinis atau International Classification of Procedure Code, 9th Revision, Clinical Modification (ICD-9-CM) adalah standar untuk penamaan prosedur dan tindakan medis yang dikeluarkan oleh WHO

Akses terhadap ICD-9 CM dapat dilakukan melalui website pihak ketiga [website ICD-9 CM](http://www.icd9data.com/).