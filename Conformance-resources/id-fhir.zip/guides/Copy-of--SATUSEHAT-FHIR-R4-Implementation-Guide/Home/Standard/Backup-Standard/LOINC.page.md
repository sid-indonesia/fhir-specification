## {{page-title}}

Logical Observation Identifiers Name and Codes (LOINC) adalah database dan standar universal untuk mengidentifikasi pengamatan laboratorium medis. Memudahkan pemahaman kode karena terdiri dari sekelompok identifikasi, nama, dan kode untuk mengidentifikasi pengukuran kondisi, observasi, dan dokumen kesehatan

Akses terhadap LOINC dapat dilakukan melalui website pihak ketiga [LOINC search](https://loinc.org/search/).

Anda memerlukan untuk membuat akun terlebih dahulu sebelum mengakses website LOINC search