## {{page-title}}

SNOMED Clinical Terms (CT) adalah sebuah sistem yang menyediakan kosakata komprehensif konsep medis, termasuk kondisi medis dan anatomi, serta tes medis, perawatan, dan prosedur.

Akses terhadap SNOMED-CT dapat dilakukan melalui website pihak ketiga [SNOMED IPS Browser](https://ips-browser.snomedtools.org/).