# {{page-title}}
Defines the ID Core constraints and extensions on the FamilyMemberHistory resource for significant health conditions for a person related to the patient relevant in the context of care for the patient.

## Usage
FamilyMemberHistory is one of the event resources in the FHIR workflow specification.

This resource records significant health conditions for a particular individual related to the subject. This information can be known to different levels of accuracy. Sometimes the exact condition ('asthma') is known, and sometimes it is less precise ('some sort of cancer'). Equally, sometimes the person can be identified ('my aunt Agatha') and sometimes all that is known is that the person was an uncle.

This resource represents a simple structure used to capture an 'elementary' family history for a particular family member. However, it can also be the basis for capturing a more rigorous history useful for genetic and other analysis - refer to the Genetic Pedigree profile for an example.

The entire family history for an individual can be represented by combining references to FamilyMemberHistory instances into a List resource instance.


## URL
|Type|URL|
|-
|Canonical|https://fhir.kemkes.go.id/r4/StructureDefinition/FamilyMemberHistory|

## Structure
### Snapshot
<div>
{{tree:id-fhir/familymemberhistory, snapshot}}
</div>

## Examples

## Dictionary
{{dict:id-fhir/familymemberhistory}} 
