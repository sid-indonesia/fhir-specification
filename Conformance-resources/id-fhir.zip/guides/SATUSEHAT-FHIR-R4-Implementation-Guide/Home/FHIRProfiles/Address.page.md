# {{page-title}}
Defines the ID Core constraints and extensions on the Address resource.

## Usage

## URL
|Type|URL|
|-
|Canonical|https://fhir.kemkes.go.id/r4/StructureDefinition/Address|

## Structure
### Snapshot
<div>
{{tree:id-fhir/address, snapshot}}
</div>

## Examples

## Dictionary
{{dict:id-fhir/address}} 
