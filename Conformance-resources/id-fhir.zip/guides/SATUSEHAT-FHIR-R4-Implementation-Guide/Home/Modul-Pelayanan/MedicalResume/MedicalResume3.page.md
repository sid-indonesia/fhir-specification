<h1><a href="https://simplifier.net/guide/SATUSEHAT-FHIR-R4-Implementation-Guide/Home/UseCase/MedicalResume/MedicalResume3.page.md?version=current"  style="color:black">Medical Resume Part 3 -- Peresepan dan Dispense Obat</a></h1>


<br>
<p style="text-align:right"><a href="#">Back to top</a></p>
<br>
<hr>