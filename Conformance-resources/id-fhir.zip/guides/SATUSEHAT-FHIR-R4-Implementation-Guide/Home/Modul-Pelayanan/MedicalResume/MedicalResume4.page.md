<h1><a href="https://simplifier.net/guide/SATUSEHAT-FHIR-R4-Implementation-Guide/Home/UseCase/MedicalResume/MedicalResume4.page.md?version=current"  style="color:black">Medical Resume Part 4 -- Laboratorium</a></h1>


<br>
<p style="text-align:right"><a href="#">Back to top</a></p>
<br>
<hr>