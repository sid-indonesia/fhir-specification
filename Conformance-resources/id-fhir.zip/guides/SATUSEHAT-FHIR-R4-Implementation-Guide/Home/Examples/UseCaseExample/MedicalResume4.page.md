# Medical Resume Part 4 -- Laboratorium
