# Medical Resume Part 1 -- Kunjungan dan Diagnosis

