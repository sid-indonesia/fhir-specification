# Medical Resume Part 2 -- Tanda-tanda vital, Prosedur, Edukasi Diet
